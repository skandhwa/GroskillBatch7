package StepDefinition22;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition23 {
	
	
	@Before(order=1)
	public void beforeTest()
	{
		System.out.println("This is before hooks order 1");
	}
	

	@Before(order=-2)
	public void beforeTest2()
	{
		System.out.println("This is before hooks order -2");
	}
	
	
	
	@Before("@smoke") 
	public void beforeSmoke()
	{
		System.out.println("This is before smoke only");
	}
	
	@After("@smoke") 
	public void AfterSmoke()
	{
		System.out.println("This is after smoke only");
	}
	
	@After
	public void AfterTest()
	{
		System.out.println("This is after hooks");
	}
	
	@Given("user opens the FB application")
	public void user_opens_the_fb_application() 
	{
	    
		System.out.println("user opens the FB application");
	}

	@Given("user enters the username in uname field")
	public void user_enters_the_username_in_uname_field() 
	{
	   System.out.println("user enters uname");
	}

	@Given("user enters the password in pwd field")
	public void user_enters_the_password_in_pwd_field() 
	{
		System.out.println("user enters pwd");
	}

	@When("user clicks on the login button of the application")
	public void user_clicks_on_the_login_button_of_the_application() 
	{
		System.out.println("user clicks on login button");
	}
	
	@When("the credentials entered are wrong")
	public void the_credentials_entered_are_wrong() 
	{
	   System.out.println("Wrong credentials enetered");
	}

	@Then("an error message is thrown on the screen")
	public void an_error_message_is_thrown_on_the_screen() 
	{
	    System.out.println("Error message thrown");
	}

	@Then("User will be navigated to homepage of the application")
	public void user_will_be_navigated_to_homepage_of_the_application() 
	{
		System.out.println("user navigated to home page");
	}
	
	@Given("user enters the username in uname field as {string}")
	public void user_enters_the_username_in_uname_field_as(String username) 
	{
	    System.out.println("username entered");
	}

	@Given("user enters the password in pwd field as {string}")
	public void user_enters_the_password_in_pwd_field_as(String password) {
		System.out.println("pwd entered");
	    
	}

}
