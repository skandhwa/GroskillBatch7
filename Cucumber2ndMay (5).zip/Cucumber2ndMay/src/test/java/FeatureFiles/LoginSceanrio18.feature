Feature: Validate Login functionality for FB Application

  Scenario: Login Scenario Validation with correct credentails
    Given user opens the FB application
    And user enters the username in uname field
    And user enters the password in pwd field
    When user clicks on the login button of the application
    Then User will be navigated to homepage of the application


@smoke
  Scenario: Login Scenario Validation with incorrect credentails
    Given user opens the FB application
    And user enters the username in uname field
    And user enters the password in pwd field
    When user clicks on the login button of the application
    But the credentials entered are wrong
    Then an error message is thrown on the screen
