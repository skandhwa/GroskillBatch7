/**
 * 
 */
/**
 * @author saura
 *
 */
module GroSkillBatch7_Java {
	requires java.rmi;
}