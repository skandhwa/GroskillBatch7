package Abstraction;

abstract class D1
{
	abstract void test();
	abstract void msg();
	void run()
	{
		System.out.println("I will run");
	}
	
	void display()
	{
		System.out.println("I will display");
	}
}

abstract class D2 extends D1
{
	abstract void test1();
	void run1()
	{
		System.out.println("Hello");
	}
}


class D3 extends D2
{
	void test()
	{
		System.out.println("Hello");
	}
	
	void msg()
	{
		System.out.println("Hi");
	}
	
	void test1()
	{
		System.out.println("Java");
	}
}



public class AbstractClassEx4 {

	public static void main(String[] args) {
		
		D3 obj=new D3();
		obj.test();
		obj.test1();
		obj.msg();
		obj.display();
		obj.run1();
		

	}

}
