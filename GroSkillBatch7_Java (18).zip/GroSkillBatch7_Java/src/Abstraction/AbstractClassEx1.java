package Abstraction;

abstract class A
{
	void test()
	{
		System.out.println("Hello");
	}
	
	void test1()
	{
		System.out.println("Hi");
	}
	
	abstract void display();
	abstract void msg();
	
	void test3()
	{
		System.out.println("Linux");
	}
	
	
}

class B extends A
{
	void display()
	{
		System.out.println("Java");
	}
	
	void msg()
	{
		System.out.println("C++");
	}
	
	void test2()
	{
		System.out.println("Python");
	}
	
}

//class C extends A
//{
//	void display()
//	{
//		System.out.println("Ruby");
//	}
//	
//	void msg()
//	{
//		System.out.println("Python");
//	}
//}



public class AbstractClassEx1 {

	public static void main(String[] args) {
		
//		B obj=new B();
//		obj.display();
//		obj.test();
//		obj.test1();
//		obj.msg();
		
		
		A ref=new B();
		ref.display();
		ref.test();
		ref.test1();
		ref.msg();
		ref.test3();
		
		
		
		
		
		
		
		

	}

}
