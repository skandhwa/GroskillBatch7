package StringPractice;

public class StringMethods9 {

	public static void main(String[] args) {
		
		String str="InDia";
		
	str=	str.toUpperCase();
	
	System.out.println(str);
		

	}

}
