package StringPractice;

public class StringMethods12 {

	public static void main(String[] args) {
		
		String str="@#$%abcdABCD1234";
		
	str=	str.replaceAll("[A-Z]","");
	
	System.out.println(str);
	
	
	
	String str1="****%%%%abcdABCD)))))1234";
	
	str1=str1.replaceAll("[^a-z A-Z]","");
	
	System.out.println(str1);
	
		

	}

}
