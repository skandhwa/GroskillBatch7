package StringPractice;

public class StringCountDigits {

	public static void main(String[] args) {
		
		String str="Java1234#$%^!){   ";
		
		int count=0;
		
		char []ch=str.toCharArray();
		
		for(char x:ch)
		{
			if(!Character.isLetter(x) && !Character.isDigit(x) && !Character.isWhitespace(x) )
			{
				count++;
			}
		}
		
		System.out.println("Total number of special characters are  "+count);
		
		

	}

}
