package StringPractice;

public class StringReverseEx1 {

	public static void main(String[] args) {
		
		String str="pat";
		
		str=str.concat("cummins");
		System.out.println(str);
		
		String str1=str;
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=4,4>=0//i=3,3>=0
		{
			revstr=revstr+str.charAt(i);//revstr= ""+m=m// revstr=m+a=ma
		}
		
		System.out.println("Reverse of string is  "+revstr);
		
		if(str1.equalsIgnoreCase(revstr))
		{
			System.out.println("Both String are palindrome");
		}
		
		else
		{
			System.out.println("Both String are not palindrome");
		}
		
		
		

	}

}
