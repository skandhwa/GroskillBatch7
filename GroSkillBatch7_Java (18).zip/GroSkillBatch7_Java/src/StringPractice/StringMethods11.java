package StringPractice;

public class StringMethods11 {

	public static void main(String[] args) {
		
		String str="he  llo";
		
		String str1=new String("Hello");
		
		if(str.equalsIgnoreCase(str1))
		{
			System.out.println("true");
		}
		
		else
		{
			System.out.println("false");
		}
		
		
		

}
}