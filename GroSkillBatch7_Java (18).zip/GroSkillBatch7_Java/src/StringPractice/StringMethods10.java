package StringPractice;

public class StringMethods10 {

	public static void main(String[] args) {
		
//		String str1="Selenium Java";  ///S //83
//		
//		String str2="aava"; /// a //97
//		
//	int x=	str1.compareTo(str2);
//	
//	System.out.println("Comparision of two string is  "+x);
		
		
		String str1="Hello python"; //72
		
		String str2="Hello Java";///32
		int x=	str1.compareTo(str2);
		System.out.println(x);
		
		

	}

}
