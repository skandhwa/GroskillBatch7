package StringPractice;

public class StringEx2 {

	public static void main(String[] args) {
		
		String str1="Java";
		
	str1=	str1.concat("Selenium");
		
		System.out.println(str1);
		

	}

}
