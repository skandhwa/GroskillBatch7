package StringPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="Republic";
		
//	    str=	str.substring(5);
//		
//		System.out.println(str);
		
	str=	str.substring(-2,5);
	
	System.out.println(str);
		
		
		

	}

}
