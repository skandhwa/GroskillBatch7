package StringPractice;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Republic";
		
	char ch=	str.charAt(4);
	
	System.out.println(ch);
		
		

	}

}
