package StringPractice;

public class StringMethods5 {

	public static void main(String[] args) {
		
		String str="Indianna";
		
//	int x=	str.indexOf('a');
//	
//	System.out.println("Index of a is  "+x);
		
		
		int y=str.indexOf('a',-5);
		
		System.out.println(y);
		

	}

}
