package StringPractice;

public class StringCountCharacters {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		char ch='a';
		
		int count=0;
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)==ch)
			{
				count++;
			}
		}
		
		System.out.println("count of  character a is  "+count);
		

	}

}
