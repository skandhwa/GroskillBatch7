package StringPractice;

import java.util.Arrays;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Indian";
		
		str=str.toLowerCase();
		
	    char []ch=str.toCharArray();
	    
	    System.out.println(ch);
	    
	    Arrays.sort(ch);
	    
	    for(char x:ch)
	    {
	    	System.out.print(x+" ");
	    }
		

	}

}
