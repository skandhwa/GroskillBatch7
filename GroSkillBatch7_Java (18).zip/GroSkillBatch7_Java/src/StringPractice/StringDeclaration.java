package StringPractice;

public class StringDeclaration {

	public static void main(String[] args) {
		
		String str="Hello";//By Using String literal
		
		String str2="Hello";
		
		String str1=new String("Welcome");
		
		System.out.println(str==str2);
		
		System.out.println(str==str1);
		

	}

}
