package StringPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
//		String str="tip@tap@toe";
//		
//	String []s1=	str.split("@");
//	
////	for(String x:s1)
////	{
////		System.out.print(x+" ");
////	}
//	
//	System.out.println(s1[2]);
		
		
		String str="NAB&&Australia&&Bangalore";
		
	String []s1=	str.split("&");
	
	for(String x:s1)
	{
		System.out.println(x);
	}
		
		
		

	}

}
