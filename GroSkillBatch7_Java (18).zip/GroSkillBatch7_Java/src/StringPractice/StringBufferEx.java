package StringPractice;

public class StringBufferEx {

	public static void main(String[] args) {
		
//		StringBuffer sb=new StringBuffer("Harry");
//		
//		sb.append("hello");
//		
//		System.out.println(sb);
		
		
		StringBuilder sb=new StringBuilder("Harry");
		sb.append("Jamiey");
		
		System.out.println(sb);

	}

}
