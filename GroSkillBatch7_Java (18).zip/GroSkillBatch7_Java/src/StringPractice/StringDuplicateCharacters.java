package StringPractice;

public class StringDuplicateCharacters {

	public static void main(String[] args) {
		
		String str="madam";
		
		for(int i=0;i<str.length();i++)//i=0,0<5//i=2,1<5
		{
			int count=1;//count=1
			
			for(int j=i+1;j<str.length();j++)//
			{
				if(str.charAt(i)==str.charAt(j))///
				{
					count++;
				}
			}
			if(count>1)
			{
				System.out.println(str.charAt(i));
			}
			
		}
		
		
		

	}

}
