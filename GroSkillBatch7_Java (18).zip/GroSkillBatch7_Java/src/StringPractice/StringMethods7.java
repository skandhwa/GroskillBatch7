package StringPractice;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="Java Python Selenium Java";
		
	str=	str.replaceFirst("Java", "Python");
	
	System.out.println(str);
	
//	str=	str.replaceFirst('J', 'P');
//	
//	System.out.println(str);
		

	}

}
