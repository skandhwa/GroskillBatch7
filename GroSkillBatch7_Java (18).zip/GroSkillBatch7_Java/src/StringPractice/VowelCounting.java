package StringPractice;

public class VowelCounting {

	public static void main(String[] args) {
		
		String str= "Tip Tap Toe";
		
		str=str.toLowerCase();
		
		int vowelcount=0,conscount=0;
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a' || str.charAt(i)=='e' || str.charAt(i)=='i'
				
					|| str.charAt(i)=='o' || str.charAt(i)=='u')
			{
				vowelcount ++;
			}
			else
			{
				conscount++;
			}
			
		}
		
		
		System.out.println("Total Vowels are  "+vowelcount);
		
		System.out.println("Total Consonant are  "+conscount);

	}

}
