package StringPractice;

public class StringMethods6 {

	public static void main(String[] args) {
		
//		String str="Republic India Republic";
//		
//	//str=	str.replace('u','d');
//		
//		//System.out.println(str);
//		
////		str=str.replace("Republic","Democratic");
////		
////		System.out.println(str);
////		
//		
//	str=	str.replaceAll('u', 'd');
//	
//	System.out.println(str);
		

	}

}
