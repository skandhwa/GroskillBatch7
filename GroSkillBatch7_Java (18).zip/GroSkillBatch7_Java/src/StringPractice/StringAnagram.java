package StringPractice;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String[] args) {
		
		String str="grab";
		String str1="parg";
		
		str=str.toLowerCase();
		str1=str1.toLowerCase();
		
		if(str.length()!=str1.length())
		{
			System.out.println("Both String  are not anagram");
		}
		
		else
		{
			char []ch=str.toCharArray();
			char []ch1=str1.toCharArray();
			Arrays.sort(ch);
			Arrays.sort(ch1);
			
			if(Arrays.equals(ch,ch1)==true)
			{
				System.out.println("Both String are anagram");
			}
			
			else
			{
				System.out.println("Both String are not anagram");
			}
			
			
		}
		
		
		
		

	}

}
