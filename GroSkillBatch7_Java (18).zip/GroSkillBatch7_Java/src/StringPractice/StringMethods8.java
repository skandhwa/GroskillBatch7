package StringPractice;

public class StringMethods8 {

	public static void main(String[] args) {
		
		String str="    Ind   ia    ";
		
		str=str.trim();
		
		System.out.println(str);
		

	}

}
