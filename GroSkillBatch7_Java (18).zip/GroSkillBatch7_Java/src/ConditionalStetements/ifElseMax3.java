package ConditionalStetements;

public class ifElseMax3 {

	public static void main(String[] args) {
		
		int a=20,b=30,c=50;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("Max is  "+a);
			}
			else
			{
				System.out.println("Max is  "+c);
			}
		}
		
		else
		{
			if(b>c)
			{
				System.out.println("Max is  "+b);
			}
			else
			{
				System.out.println("Max is  "+c);
			}
		}
		
		

	}

}
