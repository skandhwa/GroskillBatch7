package ConditionalStetements;

public class UsingLogicalOperatorEx {

	public static void main(String[] args) {
		
		int a=20,b=40,c=60;
		
		if(a<b && a<c  && c<b)
		{
			System.out.println("Yes");
		}
		
		else
		{
			System.out.println("No");
		}
		
		

	}

}
