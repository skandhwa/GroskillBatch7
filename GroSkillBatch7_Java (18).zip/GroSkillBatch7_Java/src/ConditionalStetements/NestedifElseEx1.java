package ConditionalStetements;

public class NestedifElseEx1 {

	public static void main(String[] args) {
		
		int age=15;
		char immigration='N';
		boolean appliedVoterCard=true;
		
		if(age>18)
		{
			System.out.println("You are elligible to vote");
		}
		
		else
		{
			
				System.out.println("You are not elligible");
				
				if(immigration=='Y')
				{
					System.out.println("You are not citizen of india");
				}
				else
				{
					System.out.println("You are citizen but you dont have votercard");
					
					if(appliedVoterCard==true)
					{
						System.out.println("You can vote in next election");
					}
					
					else
					{
						System.out.println("Please apply for voter card");
					}
					
					
				}
				
				
				
				
			
		}
		

	}

}
