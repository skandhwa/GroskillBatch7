package ConditionalStetements;

public class ElseIFLadder {

	public static void main(String[] args) {
		
		int a=20,b=30,c=40,d=50,e=60;
		
		if(a>b && a>c && a>d && a>e)
		{
			System.out.println("Max is a "+a);
		}
		
		else if(b>a && b>c && b>d && b>e)
		{
			System.out.println("Max is b "+b);
		}
		
		else if(c>a && c>b && c>d && c>e)
		{
			System.out.println("Max is c "+c);
		}
		
		else if(d>a && d>b && d>c && d>e)
		{
			System.out.println("Max is d "+d);
		}
		
		else
		{
			System.out.println("Max is  "+e);
		}
		
		

	}

}
