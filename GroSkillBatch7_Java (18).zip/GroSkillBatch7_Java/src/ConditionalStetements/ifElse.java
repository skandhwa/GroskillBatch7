package ConditionalStetements;

public class ifElse {

	public static void main(String[] args) {
		
		int x=20,y=30;
		
		if(x>y)
		{
			System.out.println("Max is "+x);
		}
		
		else
		{
			System.out.println("Max is  "+y);
		}
		
		

	}

}
