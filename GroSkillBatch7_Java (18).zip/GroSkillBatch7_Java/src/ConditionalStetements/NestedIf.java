package ConditionalStetements;

public class NestedIf {

	public static void main(String[] args) {
		
		int age=85;
		
		if(age>18)
		{
			System.out.println("You are elligible to vote");
			
			if(age>60)
			{
				System.out.println("You can vote online");
				
				if(age>80)
				{
					System.out.println("You can vote from home , someone will come to take your vote");
				}
			}
		}
		

	}

}
