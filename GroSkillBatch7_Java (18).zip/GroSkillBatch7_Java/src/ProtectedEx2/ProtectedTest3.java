package ProtectedEx2;

import ProtectedEx1.ProtectedTest1;

public class ProtectedTest3 extends ProtectedTest1 {

	public static void main(String[] args) {
		
		ProtectedTest3 obj=new ProtectedTest3();
		obj.display();
		

	}

}
