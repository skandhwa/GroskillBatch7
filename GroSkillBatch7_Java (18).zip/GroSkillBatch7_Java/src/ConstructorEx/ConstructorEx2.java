package ConstructorEx;

class A4
{
	int id;
	String name;
	double salary;
	
	A4()
	{
		System.out.println("hello");
	}
	
	A4(int i,String n)
	{
		id=i;
		name=n;
	}
	
	A4(int i,String n,double s )
	{
		id=i;
		name=n;
		salary=s;
	}
	
	A4(String n,int i)
	{
		name=n;
		id=i;
	}
	
	void display()
	{
		System.out.println(id+" "+name+"  "+salary);
	}
}




public class ConstructorEx2 {

	public static void main(String[] args) {
		
		
		A4 obj=new A4();
		obj.display();
		
		A4 obj2=new A4("Harry",90);
		obj2.display();
		
		A4 obj1=new A4(10,"Tom");
		obj1.display();
		
		A4 obj3=new A4(21,"Harry",89000);
		obj2.display();
		
		
		
		

	}

}
