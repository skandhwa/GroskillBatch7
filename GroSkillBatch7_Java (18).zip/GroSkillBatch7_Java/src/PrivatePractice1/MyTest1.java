package PrivatePractice1;

public class MyTest1 
{
	
	private int x=10;
	private  void display()
	{
		System.out.println("Hello");
	}
	
	

	public static void main(String[] args) {
		
		MyTest1 obj=new MyTest1();
		obj.display();
	    System.out.println(obj.x);	
		
		

	}

}
