package InterfacePractice;

interface I16
{
	default void test()
	{
		System.out.println("I am descrbing interface");
	}
	
	void display();
	void msg();
	
}

class C30 implements I16
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void msg()
	{
		System.out.println("Hi");
	}
	
	public void test()
	{
		System.out.println("Java Selenium");
	}
	
	
}



public class DefaultMethodInterface {

	public static void main(String[] args) {
		
		I16 ref=new C30();
		ref.display();
		ref.msg();
		ref.test();
		
		
		
		

	}

}
