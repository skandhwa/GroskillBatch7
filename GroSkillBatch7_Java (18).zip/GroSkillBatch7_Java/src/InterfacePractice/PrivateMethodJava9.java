package InterfacePractice;

interface I25
{
	private void test()
	{
		System.out.println("common");
	}
	
	private void msg() {
		
		System.out.println("hello Java");
	}
	
	default void display()
	{
		test();
		msg();
	}
	
	
	
	
	
	
	
	
}




public class PrivateMethodJava9 implements I25{

	public static void main(String[] args) {
		
		PrivateMethodJava9 obj=new PrivateMethodJava9();
		obj.display();
		
		

	}

}
