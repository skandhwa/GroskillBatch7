package InterfacePractice;

interface Shape
{
	double area(int r,int h);	
	double volume(int r,int h);
	double pi=3.14;
}

class Cyllinder implements Shape
{
	public double area(int r,int h)
	{
		return pi*r*r*h;
	}
	public double volume(int r,int h)
	{
		return 1.33*pi*r*r*r*h;
	}
	
}


class Sphere implements Shape
{
	public double area(int r,int h)
	{
		return 4*pi*r*r*h;
	}
	public double volume(int r,int h)
	{
		return 4*pi*r*r*r*h;
	}
}


public class InterfaceRealTime 
{

	public static void main(String[] args) {
		
		Shape ref=new Cyllinder();
		ref.area(12, 13);
		ref.volume(5, 9);
		
		Shape ref1=new Sphere();
		ref1.area(6, 8);
		ref1.volume(4, 3);
		
		

	}

}
