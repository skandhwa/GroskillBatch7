package InterfacePractice;

interface I1
{
	void display();
	void msg();
	int x=20;
}

class C1 implements I1
{
	public void display()
	{
		System.out.println("Hello");
	}
	public void msg()
	{
		System.out.println("Hi");
	}
	
}




public class InterfaceEx1 {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.display();
		obj.msg();
		
		I1 ref=new C1();
		ref.display();
		ref.msg();
		
		
		
		
		

	}

}
