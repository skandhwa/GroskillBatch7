package InterfacePractice;

interface I15
{
	static void test()
	{
		System.out.println("Hello");
	}
}



public class InterfaceEx4 {

	public static void main(String[] args) {
		
	I15.test();	
		

	}

}
