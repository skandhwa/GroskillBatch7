package InterfacePractice;

interface I7
{
	void display();
}
interface I8 extends I7
{
	void test();
}

class C10 implements I8
{
	public void display()
	{
		System.out.println("Hi");
	}
	
	public void test()
	{
		System.out.println("Hello");
	}
}






public class InterfaceEx3 {

	public static void main(String[] args) {
		
		C10 obj=new C10();
		obj.display();
		obj.test();
		

	}

}
