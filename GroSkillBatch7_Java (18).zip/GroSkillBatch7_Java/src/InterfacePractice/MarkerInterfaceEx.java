package InterfacePractice;

import java.io.Serializable;
import java.rmi.Remote;

public class MarkerInterfaceEx implements Remote  {

	public static void main(String[] args) {
		

		System.out.println("Hello");
		
	}

}
