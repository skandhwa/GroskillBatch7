package InterfacePractice;

interface D1
{
	void test();
	int x=15;
	
}

interface D2
{
	void msg();
	
}

class C15 implements D1,D2
{
	public void test()
	{
		System.out.println("Hello");
	}
	
	public void msg()
	{
		System.out.println("Hi");
	}
}




public class MultipleInheritanceClass {

	public static void main(String[] args) {
		
		
//		D1 ref=new C15();
//		ref.test();
//		
//		D2 ref1=new C15();
//		ref1.msg();
		
		C15 obj=new C15();
		obj.test();
		obj.msg();
		
		System.out.println(D1.x);
		
		

	}

}

