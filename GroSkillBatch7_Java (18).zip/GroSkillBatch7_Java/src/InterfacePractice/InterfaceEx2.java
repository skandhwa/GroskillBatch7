package InterfacePractice;

interface I2
{
	 void display();
	 void test();
	 void msg();
	 int x=23;
	
}

class C2 implements I2
{
	public void display()
	{
		System.out.println("Hello");
	}
	public void test()
	{
		System.out.println("Java");
	}
	public void msg()
	{
		System.out.println("Python");
	}
	
	
	
	
}

class C3 implements I2
{
	public void display()
	{
		System.out.println("Hello");
	}
	public void test()
	{
		System.out.println("Java");
	}
	
	public void msg()
	{
		System.out.println("Python");
	}
	
}





public class InterfaceEx2 {

	public static void main(String[] args) {
		
		I2 ref=new C2();
		ref.display();
		ref.test();
		ref.msg();
		
		I2 ref1=new C3();
		ref1.display();
		ref1.test();
		ref1.msg();
		

	}

}
