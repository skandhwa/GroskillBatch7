package StaticKeyword;

class D2
{
	static String colour="red";
}

class D3 extends D2
{
	static String colour="black";
	 void run()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
}


public class SuperWithSTatic {

	public static void main(String[] args) {
		
		D3 obj=new D3();
		obj.run();
		

	}

}
