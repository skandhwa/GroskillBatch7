package StaticKeyword;

public class StaticBlocks {
	
	static
	{
		System.out.println("Hello How r u");
	}
	
	

	public static void main(String[] args) {
	
       System.out.println("Java Selenium");
		
	}

}
