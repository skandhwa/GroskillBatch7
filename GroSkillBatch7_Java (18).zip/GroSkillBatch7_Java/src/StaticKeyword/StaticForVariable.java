package StaticKeyword;

class C1
{
	int id;
	String eName;
	static String cmpName="TCS";
	
	C1(int i, String e)
	{
		id=i;
		eName=e;
		
	}
	
	void change()
	{
		cmpName="CTS";
	}
	
	void display()
	{
		System.out.println(id+"  "+eName+"  "+cmpName);
	}
	
}
public class StaticForVariable {

	public static void main(String[] args) {
		
		
		C1 obj=new C1(1234,"Harry");
		C1 obj1=new C1(4567,"Tom");
		C1 obj2=new C1(9875,"Jack");
		obj2.change();
		
		obj.display();
		
		obj1.display();
		obj2.display();
		
		

	}

}
