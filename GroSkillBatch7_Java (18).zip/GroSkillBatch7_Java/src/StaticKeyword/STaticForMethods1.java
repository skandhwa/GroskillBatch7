package StaticKeyword;

class C3
{
	static void test()
	{
		System.out.println("Hello");
	}
}



public class STaticForMethods1 {

	public static void main(String[] args) {
		
		C3.test();
		

	}

}
