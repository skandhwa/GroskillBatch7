package StaticKeyword;

class D1
{
	static int id;
	static String name;
	
	 D1(int i,String n)
	{
		id=i;
		name=n;
	}
	 
	static  void display()
	 {
		 System.out.println(id+"  "+name);
	 }
	 
}



public class StaticForConstructor {

	public static void main(String[] args) {
		

	}

}
