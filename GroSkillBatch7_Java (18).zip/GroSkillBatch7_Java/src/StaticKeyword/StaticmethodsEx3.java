package StaticKeyword;

class C5
{
	static int x=5;
	
	static void show()
	{
		  x=10;
	}
	
	static void display()
	{
		 int y=20;
	}
	
	
	
}

public class StaticmethodsEx3 {

	public static void main(String[] args) {
		

	}

}
