package ProtectedEx1;




public class ProtectedTest2 {

	public static void main(String[] args) {
		
		ProtectedTest1 obj=new ProtectedTest1();
		obj.display();
		
		
		

	}

}
