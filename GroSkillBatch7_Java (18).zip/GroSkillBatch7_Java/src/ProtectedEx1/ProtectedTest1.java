package ProtectedEx1;

public class ProtectedTest1 {
	
	protected void display()
	{
		System.out.println("Hello");
	}
	

	public static void main(String[] args) {
		
		ProtectedTest1 obj=new ProtectedTest1();
		obj.display();
		

	}

}
