package PolymorphismEx;

class B30
{
	final static  int a=30;
	
	void test()
	{
		a=40;
		System.out.println(a);
	}
	
}



public class FinalForVariable {

	public static void main(String[] args) {
		
		B30 obj=new B30();
		obj.test();
		

	}

}
