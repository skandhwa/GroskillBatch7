package PolymorphismEx;

class D18
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static int add(int x,int y,int z)
	{
		return x+y+z;
	}
}



public class StaticMethodOverload {

	public static void main(String[] args) {
		
	System.out.println(D18.add(45, 78));	
	System.out.println (D18.add(45, 78,89));

	}

}
