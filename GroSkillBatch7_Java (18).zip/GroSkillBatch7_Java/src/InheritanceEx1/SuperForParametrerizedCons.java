package InheritanceEx1;

class Shape1
{
	Shape1(String S)
	{
		System.out.println(S);
	}
}

class Volume1 extends Shape1
{
   Volume1()
   {
	   super("Calculating Shape Volume");
	   System.out.println("Calculating other volume");
   }
	
}




public class SuperForParametrerizedCons {

	public static void main(String[] args) {
		
		Volume1 obj=new Volume1();
		
		
		
		
		
		
		

	}

}
