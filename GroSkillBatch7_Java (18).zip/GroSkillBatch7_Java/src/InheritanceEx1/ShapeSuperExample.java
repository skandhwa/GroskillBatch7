package InheritanceEx1;

class Shape
{
	int volume(int r,int h)
	{
		return r*h;
	}
}

class Dimensions extends Shape
{
	int volume(int r,int h)
	{
		return 3*r*h;
	}
	int area(int r )
	{
		return r*r;
	}
	
	int tsa(int r,int h)
	{
		return r*r*h;
	}
	
	int result()
	{
		int r=super.volume(34, 45);
		return r;
		
	}
	
	
	
	
}





public class ShapeSuperExample {

	public static void main(String[] args) {
		
		
		Dimensions obj=new Dimensions();
	System.out.println(obj.volume(12,13));	
	System.out.println	(obj.result());
		
		
		
		
		

	}

}
