package InheritanceEx1;

class A1
{
	void test()
	{
		System.out.println("Hello");
	}
}

class B1 extends A1
{
	void display()
	{
		System.out.println("Hi");
	}
}

class C1 extends B1
{
	void msg()
	{
		System.out.println("Java");
	}
}


public class MultiLevelInheritanceEx {

	public static void main(String[] args) {
		
		C1 obj=new C1();
		obj.msg();
		obj.test();
		obj.display();
		
		

	}

}
