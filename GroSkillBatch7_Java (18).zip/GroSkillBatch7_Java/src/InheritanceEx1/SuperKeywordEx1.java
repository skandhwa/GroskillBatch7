package InheritanceEx1;

class Mammal
{
	String colour="blue";
	
	void test2()
	{
		System.out.println("Python");
	}
}


class Animal extends Mammal
{
	String colour="red";
	
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
		
	}
	
}

class Dog extends Animal
{
	String colour="black";
	void test()
	{
		System.out.println(colour);
		System.out.println(super.colour);
	}
	
	
}




public class SuperKeywordEx1 {

	public static void main(String[] args) {
		
		Dog obj=new Dog();
		obj.test();
		

	}

}
