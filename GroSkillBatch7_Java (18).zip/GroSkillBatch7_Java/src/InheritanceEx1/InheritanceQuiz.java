package InheritanceEx1;

class A60
{
	void test()
	{
		System.out.println("hello");
	}
}

class A61 extends A60
{
	void test1()
	{
		System.out.println("Hi");
	}
}

class A62 extends A61
{
	void msg()
	{
		System.out.println("Java");
	}
}




public class InheritanceQuiz {

	public static void main(String[] args) {
		
		A61 obj=new A61();
		obj.test();
		obj.test1();
		
	}

}
