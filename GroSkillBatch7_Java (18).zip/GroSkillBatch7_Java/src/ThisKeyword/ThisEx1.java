package ThisKeyword;

class D8
{
	 int id;
	 String name;
	
	D8(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	void display()
	{
		System.out.println(id+"  "+name);
	}
}



public class ThisEx1 {

	public static void main(String[] args) {
		
		D8 obj=new D8(1234,"Sam");
		obj.display();
		
		
		
		

	}

}
