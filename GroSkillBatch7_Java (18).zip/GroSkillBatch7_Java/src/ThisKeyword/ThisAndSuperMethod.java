package ThisKeyword;

class Bird2
{
	void fly()
	{
		System.out.println("Bird flies");
	}
}

class Pigeon extends Bird2
{
	void fly()
	{
		System.out.println("Pigeon fly");
	}
	
	void test()
	{
		System.out.println("This is test");
	}
	
	void run()
	{
		
		test();
		super.fly();
		this.fly();
	}
	
}


public class ThisAndSuperMethod {

	public static void main(String[] args) {
		

	}

}
