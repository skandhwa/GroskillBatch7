//package ThisKeyword;
//
//class D15
//{
//	D15()
//	{
//		System.out.println("Hello");
//	}
//}
//
//class D16 extends D15
//{
//	D16()
//	{
//		
//		this();
//		super();
//	}
//}
//
//
//
//public class ThisForConstrutor {
//
//	public static void main(String[] args) {
//		
//
//	}
//
//}
