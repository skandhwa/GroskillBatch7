package ThisKeyword;

class Student
{
	static int id;
	
	Student(int id)
	{
		this.id=id;
	}
	
	
	static void show()
	{
		System.out.println(id);
	}
	
}


public class ThisandStatic {

	public static void main(String[] args) {
		
		Student obj=new Student(34);
		obj.show();
		

	}

}
