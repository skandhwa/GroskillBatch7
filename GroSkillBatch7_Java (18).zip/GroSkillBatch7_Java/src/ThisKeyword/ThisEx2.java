package ThisKeyword;

class D9
{
	int id;
	String name;
	float salary;
	
	D9(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	
	D9(int id,String name,float salary)
	{
		this(id,name);
		this.salary=salary;
	}
	
}






public class ThisEx2 {

	public static void main(String[] args) {
		

	}

}
