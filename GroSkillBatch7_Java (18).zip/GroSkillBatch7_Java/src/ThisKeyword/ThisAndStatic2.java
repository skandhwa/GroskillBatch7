package ThisKeyword;

class Student2
{
	 int x=20;
	
	static void test()
	{
		System.out.println(this.x);
	}
}



public class ThisAndStatic2 {

	public static void main(String[] args) {
		

	}

}
