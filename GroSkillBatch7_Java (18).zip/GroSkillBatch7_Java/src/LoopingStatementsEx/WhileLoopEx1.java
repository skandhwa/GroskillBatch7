package LoopingStatementsEx;

public class WhileLoopEx1 {

	public static void main(String[] args) {
		
		int i=1;// assignment
		
		while(i<=5)//1<=5//2<=5//3<=5//4<=5//5<=5//6<=5/// Condition checking
		{
			System.out.println(i);//1//2//3//4//5
			i++;///Increment/decrement operation
		}
		
		
//		int r=5%10;
//		System.out.println(r);
		
	}

}
