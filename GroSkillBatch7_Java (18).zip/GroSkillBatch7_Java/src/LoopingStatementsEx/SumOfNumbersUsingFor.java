package LoopingStatementsEx;

public class SumOfNumbersUsingFor {

	public static void main(String[] args) {
		
		int sum=0;
		int num=578;
		
		while(num!=0)//578!=0//57!=0//5!=0//0!=0
		{
			int r=num%10;//r=578%10=8//r=57%10=7//r=5%10=5
			sum=sum+r;//sum=0+8=8//sum=8+7=15//sum=15+5=20
			num=num/10;//num=578/10=57//num=57/10=5///num=5/10=0
		}
		
		System.out.println("Sum of numbers is  "+sum);
		
		
		

	}

}
