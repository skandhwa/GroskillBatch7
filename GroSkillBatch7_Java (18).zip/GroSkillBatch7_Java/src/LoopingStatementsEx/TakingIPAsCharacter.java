package LoopingStatementsEx;

import java.util.Scanner;

public class TakingIPAsCharacter {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Input as Character");
		
		char ch=sc.next().charAt(0);
		
		
		System.out.println("The character entered by you is  "+ch);
		
		

	}

}
