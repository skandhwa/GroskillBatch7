package LoopingStatementsEx;

public class doWhileEx {

	public static void main(String[] args) {
		
		int i=1;
		do
		{
			System.out.println(i);//1//2//3//4
			i++;//1++//2++//3++//4++
		}
		
		while(i<5); /// 2<5//3<5//4<5//5<5
		
		

	}

}
