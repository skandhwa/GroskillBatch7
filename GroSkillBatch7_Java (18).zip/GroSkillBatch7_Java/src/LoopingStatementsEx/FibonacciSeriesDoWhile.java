package LoopingStatementsEx;

public class FibonacciSeriesDoWhile {

	public static void main(String[] args) {
		
		int n1=0;
		int n2=1;
		int n3;
		
		int count=5;
		
		int i=1;
		
		do
		{
			System.out.print(n1 +"  ");/// 0//1//1//2
			n3=n1+n2;///n3=0+1=1//n3=1+1=2//n3=1+2=3
			n1=n2;//n1=1//n1=1//n1=2
			n2=n3;//n2=1//n2=2//n2=3
			
			i++;///1++//2++//3++
			
		}
		
		while(i<=count);///2<=5///3<=5//4<=5
		

	}

}
