package LoopingStatementsEx;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		
		int n=19;
		
        boolean isPrime=true;
		
		for(int i=2;i<=n/2;i++)//  i=2,2<=9
		{
			if(n%i==0)//16%2=0///19%2
			{
				isPrime=false;
				break;
			}
			
			
		}
		
		
		
		System.out.println(isPrime? "Prime":"Not Prime");

	}

}
