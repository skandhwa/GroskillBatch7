package LoopingStatementsEx;

public class ArmstrongNumber {

	public static void main(String[] args) {
		
		int num=135;
		int x=num;//x=153
		
		int d;
		
		int sum=0;
		
		
		while(x!=0)//153!=0///15!=0///1!=0
		{
			d=x%10;////// d=153%10=3   ///d=15%10=5  ///d=1%10=1
			sum=sum+d*d*d;///sum=0+27=27//sum=27+125=152///sum=152+1=153
			x=x/10;//x=153/10=15///x=15/10=1///x=1/10=0
			
			
			
		}
		
		if(sum==num)
		{
			System.out.println("Armstrong number");
		}
		
		else
		{
			System.out.println("Not Armstrong");
		}
		
		
		
		

	}

}
