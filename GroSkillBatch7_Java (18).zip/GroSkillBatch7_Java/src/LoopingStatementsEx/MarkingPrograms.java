package LoopingStatementsEx;

import java.util.Scanner;

public class MarkingPrograms {

	public static void main(String[] args) {
		
	   System.out.println("Enter your grade");
	   
	   Scanner sc=new Scanner(System.in);
	   
	  char grade=sc.next().charAt(0);
	   
	   switch(grade)
	   {
	   case 'A':
		   System.out.println("You got marks greater than 90 and less than 100");
		   break;
	   
	   case 'B':
		   System.out.println("You got marks greater than 80 and less than 90");
		   break;
		
	   case 'C':
		   System.out.println("You got marks greater than 70 and less than 80");
		   break;	   
	   	   
	   case 'D':
		   System.out.println("You got marks greater than 60 and less than 70");
		   break;  
		   
	   case 'E':
		   System.out.println("You got marks greater than 50 and less than 60");
		   break;
		   
	   default:
		  System.out.println("Invalid choice"); 
		  
		  
		   
		   
	   }
	   
		

	}

}
