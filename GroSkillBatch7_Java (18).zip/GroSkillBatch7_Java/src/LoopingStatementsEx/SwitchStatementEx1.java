package LoopingStatementsEx;

import java.util.Scanner;

import java.util.Scanner;

public class SwitchStatementEx1 {

	public static void main(String[] args) {
		
		int choice;
		
		System.out.println("Enter your choice");
		
		Scanner sc=new Scanner(System.in);
		
		choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
			
			System.out.println("This is first choice");
            break;
            
		case 2:
			System.out.println("This is second choice");
			break;
		
		case 3:
			System.out.println("This is third choice");
			break;
		
		case 4:
			System.out.println("This is fourth choice");
			break;
			
		default:
			System.out.println("This is invalid choice");
            
		}
		

	}

}
