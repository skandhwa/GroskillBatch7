package LoopingStatementsEx;

public class BreakStatementEx {

	public static void main(String[] args) {
		
		for(int i=1;i<=8;i++)//i=1,1<=4//i=2,2<=4//i=3,3<=4
		{
			if(i==5)///1==3
			{
				break;
			}
			
			System.out.println(i);//1//2
		}
		
		

	}

}
