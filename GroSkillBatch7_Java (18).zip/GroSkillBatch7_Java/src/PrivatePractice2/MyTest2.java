package PrivatePractice2;

class A
{
	private void display()
	{
		System.out.println("Hello How r u");
	}
}


public class MyTest2 {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.di
		

	}

}
