package MyBasics;

public class DataTypesEx1 {

	public static void main(String[] args) {
		
		boolean flag=false;
		
		byte x=125;  //-128 to +127
		
		short y=6431; /// -32768 to +32767
		
		int k=1231232155;
		
		long j=2134123123213l;
		
		float n=21334324323232343243242232432432421321.345432343234324323432424243254f;
		
		double h=213123213123123123123.213321321321312321;
		
		
		

	}

}
