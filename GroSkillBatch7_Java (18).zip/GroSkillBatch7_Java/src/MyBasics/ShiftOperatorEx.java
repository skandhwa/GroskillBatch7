package MyBasics;

public class ShiftOperatorEx {

	public static void main(String[] args) {
		
		
//		int x=4;
//		
//		System.out.println(x<<5);
//		
//		
//		/// 30 / 2pow3=30*8=240
		
		
		int a=200;
		
		System.out.println(a>>4);// 200 / 2pow4

	}

}
