package MyBasics;

public class MyPractice {

	public static void main(String[] args) {
		
		System.out.println("Hello");
		
		

	}

}
