package MyBasics;

class B
{
	void test()
	{
		System.out.println("hello");
	}
	
	void display()
	{
		System.out.println("Hi");
	}
}



public class ClassAndObjectsEx {

	public static void main(String[] args) {
		
		B obj=new B();
		
		obj.test();
		
		obj.display();
		
		
		
		
		

	}

}
