package MyBasics;

class A5
{
	int sum(int x,int y)
	{
		return x+y;
	}
	
	double diff(int a,int b,int c)
	{
		 return a-b-c;
	}
	
	boolean isMarried(boolean  x)
	{
		return x;
	}
	
}


public class MethodEx3 {

	public static void main(String[] args) {
		
		A5 obj=new A5();
		
	System.out.println(obj.sum(12, 20));	
	
	
	System.out.println(obj.diff(100, 30, 20));  
	
	System.out.println (obj.isMarried(true));
		
	
		

	}

}
