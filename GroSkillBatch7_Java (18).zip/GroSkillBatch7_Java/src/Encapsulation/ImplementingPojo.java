package Encapsulation;

public class ImplementingPojo {

	public static void main(String[] args) {
		
		
		EmployeePOJO obj=new EmployeePOJO();
		
		obj.setId(456);
		System.out.println(obj.getId());
		
		obj.setMarried(false);
        System.out.println(obj.isMarried());		
        
        obj.setName("Harry");
        
        System.out.println(obj.getName());

	}

}
