package Encapsulation;

public class EncapsulatedClassEx2 {

	public static void main(String[] args) {
		
		E1 obj=new E1();
	System.out.println(obj.getName());	

	}

}
