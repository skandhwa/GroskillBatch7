package Encapsulation;

class E1
{
	private int id;
	private String name="Saurabh";
	private boolean isMarried;
	
	
	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public boolean isMarried() 
	{
		return isMarried;
	}
	public void setMarried(boolean isMarried) 
	{
		this.isMarried = isMarried;
	}
	
	
	
	
}



public class EncapsulatedClass {

	public static void main(String[] args) {
		
		E1 obj=new E1();
		obj.setId(23);
	System.out.println(obj.getId());	
		
		

	}

}
