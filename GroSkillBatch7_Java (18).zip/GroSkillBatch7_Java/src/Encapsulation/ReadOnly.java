package Encapsulation;

class E2
{
	private int id=34;
	private String name="John";
	private boolean isMarried=true;
	
	
	public int getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public boolean isMarried() {
		return isMarried;
	}
	
	
	
	
	
}

public class ReadOnly {

	public static void main(String[] args) {
		
		E2 obj=new E2();
	System.out.println(obj.getId());	
	System.out.println	(obj.isMarried());
	System.out.println	(obj.getName());
		

	}

}
