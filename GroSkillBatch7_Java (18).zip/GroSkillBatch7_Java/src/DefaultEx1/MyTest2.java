package DefaultEx1;

public class MyTest2 {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
		
		

	}

}
