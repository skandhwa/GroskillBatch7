package DefaultEx1;

class A
{
	void display()
	{
		System.out.println("I am display method");
	}
}


public class MyTest1 {

	public static void main(String[] args) {
		
		A obj=new A();
		obj.display();
				
		
		
		

	}

}
