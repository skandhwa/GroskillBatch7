package ExceptionPractice;

public class ExceptionEx1 {

	public static void main(String[] args) {
		
		try
		{
		int x=20;
		int y=x/0;
		System.out.println(y);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e);
		}
		
		
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		
		
		
		

	}

}
