package ExceptionPractice;

public class ExceptionEx3 {

	public static void main(String[] args) {
		
		
		try
		{
		String str=null;
		int x=str.length();
		System.out.println("Length of string is  "+x);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e);
		}
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		

	}

}
