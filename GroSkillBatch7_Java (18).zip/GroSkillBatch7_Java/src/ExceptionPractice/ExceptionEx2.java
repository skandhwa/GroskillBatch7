package ExceptionPractice;

public class ExceptionEx2 {

	public static void main(String[] args) {
		
		try
		{
		int []arr= {1,2,4,5,6};
		
		System.out.println(arr[7]);
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		

	}

}
