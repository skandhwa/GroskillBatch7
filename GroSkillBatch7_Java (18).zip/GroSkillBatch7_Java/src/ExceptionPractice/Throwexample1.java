package ExceptionPractice;

public class Throwexample1 {

	public static void main(String[] args) {
		
		int age=15;
		
		if(age<18)
		{
			throw new IllegalArgumentException("Invalid age");
		}
		
		else
		{
			System.out.println("Your age is perfect for voting");
		}
		
		

	}

}
