package ExceptionPractice;



public class NestedTryCatch {

    public static void main(String[] args) {

        try {

            try 
            {

                String str = "hello";
                int y = str.length();
                System.out.println(y);

                try 
                {
                    int x = 9 / 0;
                    System.out.println(x);
                } 
                catch (ArithmeticException e) {
                    System.out.println("caught with " + e.getMessage());
                }

            } 
            catch (NullPointerException e) 
            {
                System.out.println("caught with " + e.getMessage());
            }

        } 
        catch (Exception e) {
            System.out.println("caught with " + e.getMessage());
        }

    }

}