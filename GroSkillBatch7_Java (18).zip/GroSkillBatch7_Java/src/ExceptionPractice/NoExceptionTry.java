package ExceptionPractice;

public class NoExceptionTry {

	public static void main(String[] args) {
		
		try
		{
			int a=9/3;
			System.out.println(a);
		}
		catch(Exception e)
		{
			System.out.println("caught with  "+e.getMessage());
			
		}
		
		
		int x=20,y=30;
		int z=x+y;
		System.out.println(z);
		

	}

}
