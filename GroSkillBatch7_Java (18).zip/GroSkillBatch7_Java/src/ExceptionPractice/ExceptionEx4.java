package ExceptionPractice;

public class ExceptionEx4 {

	public static void main(String[] args) {
		
		try
		{
		String str="abc";
		int x=Integer.parseInt(str);
		}
		
		catch(NumberFormatException e)
		{
			System.out.println("caught with "+e);
		}
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);
		

	}

}
