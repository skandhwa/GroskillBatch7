package ExceptionPractice;

public class MultiTryCatchBlock {

	public static void main(String[] args) {
		
		try
		{
		int x=20;
		int y=x/0;
		System.out.println(y);
		
		
        int []arr= {1,2,4,5,6};
		System.out.println(arr[7]);
		
		String str=null;
		int p=str.length();
		System.out.println("Length of string is  "+p);
		
		String str1="abc";
		int z=Integer.parseInt(str1);
		
		}
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		
		
		
		catch(NumberFormatException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		int a=20;
		int b=30;
		int c=a+b;
		System.out.println(c);

	}

}
