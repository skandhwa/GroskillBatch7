package ArrayPractice;

public class ArrayCopyProgram {

	public static void main(String[] args) {
		
		int []a= {10,20,30,40};
		
		int []b=new int [a.length];
		
		for(int i=0;i<a.length;i++)//i=0,0<4
		{
			b[i]=a[i];//b[1]=a[1]
		}
		
		for(int x:b)
		{
			System.out.print(x+" ");
		}
		

	}

}
