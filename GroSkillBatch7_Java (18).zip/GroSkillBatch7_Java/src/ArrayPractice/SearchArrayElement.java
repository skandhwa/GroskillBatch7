package ArrayPractice;
import java.util.Scanner;

public class SearchArrayElement {
    public static void main(String[] args) {

        int[] a = {12, 56, 3, 78, 34};

        System.out.println("Enter an element to search:");

        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();

        boolean found = false;

        for (int i = 0; i < a.length; i++) {
            if (a[i] == x) {
                System.out.println("Element found at position " + i);
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Element not found");
        }

        sc.close();
    }
}