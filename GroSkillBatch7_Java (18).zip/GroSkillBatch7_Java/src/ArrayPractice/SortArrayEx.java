package ArrayPractice;

public class SortArrayEx {

	public static void main(String[] args) {
		
		int []a= {2,1,5,0,9};
		
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5//i=2,2<5
		{
			for(int j=i+1;j<a.length;j++)//j=3,3<5//j=4,4<5//j=5,5<5
			{
				if(a[i]>a[j])///a[2]>a[3]///a[2]>a[4]
				{
					int t=a[i];///
					a[i]=a[j];
					a[j]=t;
				}
			}
			
			System.out.println(a[i]);
		}
		
		
		
		

	}

}
