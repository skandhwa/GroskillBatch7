package ArrayPractice;

import java.util.Arrays;

public class ArrayEx3 {

	public static void main(String[] args) {
		
		int []a= {12,5,6,39};
		
		Arrays.sort(a);
		
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		String str=a.toString();
		
		System.out.println(str);
		
	System.out.println(Arrays.toString(a));	
	
	
	
		
		

	}

}
