package ArrayPractice;

public class CheckArrayIsSorted {

	public static void main(String[] args) {
		
		int []a= {1,2,3,4,5};
		boolean sorted=true;
		
		for(int i=0;i<a.length;i++)//i=0,0<5
		{
			if(a[i]>a[i+1])//a[1]>a[2]
			{
				sorted=false;
				break;
			}
		}
		
		System.out.println("Is Array Sorted  "+sorted);
		

	}

}
