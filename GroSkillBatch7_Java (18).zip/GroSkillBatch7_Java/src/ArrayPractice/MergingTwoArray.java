package ArrayPractice;

public class MergingTwoArray {

	public static void main(String[] args) {
		
		int []a= {1,2,3};
		int []b= {4,5,6};
		
		int x=a.length;//x=3
		int y=b.length;//y=3
		
		int []merged= new int [x+y];//6
		
		for(int i=0;i<x;i++)//i=0,0<3
		{
			merged[i]=a[i];//merged[0]=a[0]
		}
		
		for(int i=0;i<y;i++)//i=0,0<3
		{
			merged[x+i]=b[i];//merged[3]=b[0]
		}
		
		System.out.println("Merged Array is ");
		
		for(int z:merged)
			
		{
			System.out.print(z+" ");
		}
		
		

	}

}
