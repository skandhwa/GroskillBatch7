package ArrayPractice;

import java.util.Arrays;

public class ArrayEx2 {

	public static void main(String[] args) {
		
		int []a= {12,45,67,88};
		int []b= {12,45,67,88};
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println(flag);
	
	
	int x=Arrays.compare(a,b);
	System.out.println("Comparing both arrays  "+x);
	
	
	
	
		
		

	}

}

