package ArrayPractice;

public class ArrayEx1 {

	public static void main(String[] args) {
		
		int []a=new int[5];
		
		a[0]=12;
		a[1]=22;
		a[2]=43;
		a[3]=56;
		a[4]=99;
		
		for(int i=0;i<a.length;i++)//i=0,0<5//i=1,1<5//i=2,2<5//i=3,3<5//i=4,4<5
		{
			System.out.println(a[i]);//a[0]//a[1]//a[2]//a[3]//a[4]
		}
		
		for(int x:a)
		{
			System.out.println(x);
		}
		
		
		int []b= {34,67,88,12,55};
		for(int y:b)
		{
			System.out.println(y);
		}
		
		
		
		
		

	}

}
