package ArrayPractice;

class ArrayMaxMin
{

public static  int MaxMin(int []a,int total)
{
	for(int i=0;i<total;i++)//i=0,0<5//i=1,1<5//i=2,2<5
	{
		for(int j=i+1;j<total;j++)//j=3,3<5//j=4,4<5//j=5,5<5
		{
			if(a[i]>a[j])///a[2]>a[3]///a[2]>a[4]
			{
				int t=a[i];///
				a[i]=a[j];
				a[j]=t;
			}
		}
		
		
	}
	
	// return a[0];//return a[2-1];
	return a[total-3];
	
	
	
}

}



public class MaxMinArrayElement {

	public static void main(String[] args) {
		
		int []a= {2,5,7,1,0,9};
		int x=a.length;
		
	System.out.println(ArrayMaxMin.MaxMin(a,x));	
		
		
		

	}

}
