package ArrayPractice;

public class PalindromeArrayEx {

	public static void main(String[] args) {
		
		int []a= {5,3,4,2,1};
		boolean palindrome=true;
		
		int l=a.length;//l=5
		int x=0;//x=0
		int y=l-1;//y=4
		
		while(x<y)///0<4
		{
			if(a[x]!=a[y])//
			{
				palindrome=false;
				break;
			}
			
			x++;
			y--;
			
		}
		
		System.out.println("Is the Array Palindrome "+palindrome);
		
		
		
		
		
		

	}

}
