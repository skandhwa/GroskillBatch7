package ArrayPractice;

public class SumOfAllElementsArray {

	public static void main(String[] args) {
		
		int []a= {5,7,6,3};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)
		{
			sum=sum+a[i];//sum=0+5=5//sum=5+7=12//sum=12+6=18//sum=18+3=21
		}
		
		System.out.println(sum);
		

	}

}
