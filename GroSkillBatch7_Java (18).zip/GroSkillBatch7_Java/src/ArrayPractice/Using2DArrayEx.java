package ArrayPractice;

public class Using2DArrayEx {

	public static void main(String[] args) {
		
		int [][]a= {{1,2,3},{4,5,6},{7,8,9}};
		
		for(int i=0;i<a.length;i++)//i=0,0<3//i=1,1<3
		{
			for(int j=0;j<a.length;j++)//j=0,0<3
			{
				System.out.print(a[i][j]+" ");//
			}
			
			System.out.println();
		}
		
		

	}

}
