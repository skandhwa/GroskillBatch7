package ArrayPractice;

public class JaggedArrayEx {

	public static void main(String[] args) {
		
		int [][]a= {
				
				{1,2,3},
				{4,5},
				{6,7,8,9}
				
		};
		
		//int x=a.length;
		
	//	System.out.println("Length is  "+x);
		
		System.out.println("Jagged Array is  \n");
		
		for(int i=0;i<a.length;i++)//i=0,0<3
		{
			for(int j=0;j<a[i].length;j++)//j=0,0<3
			{
				System.out.print(a[i][j]+" ");
			}
			
			System.out.println();
		}
		
		
	}

}
