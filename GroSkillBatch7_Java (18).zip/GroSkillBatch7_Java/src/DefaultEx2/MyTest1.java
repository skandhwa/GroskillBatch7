package DefaultEx2;

public class MyTest1 {

	public static void main(String[] args) {
		
		A obj=new A();
		

	}

}
