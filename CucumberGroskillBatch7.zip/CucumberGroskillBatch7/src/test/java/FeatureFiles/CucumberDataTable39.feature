Feature: Validating Cucumber Data Table

  Scenario: Filling Up Reg form through Data Table
    Given user opens the web application
    And user enters the details in below format
    
      | firstname | lastname | address | emailAdd       | phone      |
      | saurabh   | K        | Delhi   | test@gmail.com | 9832786543 |
