Feature: Validate login functionality of application



  Scenario: Validate login functionality with correct credentails
    Given user opens the web application
    And user eneters the username
    And user enters the password
    When user clicks on submit button
    Then user will be navigated to home page


@smoke
  Scenario: Validate login functionality with incorrect credentails
    Given user opens the web application
    And user eneters the username
    And user enters the password
    When user clicks on submit button
    But the user id and password is wrong
    Then user will be displayed an error message
   # Then user should correct the details
