Feature: All Ecommerce scenarios

  Background: 
    Given user opens the ecommerce app
    And user enters username as "abcd"
    And user enters password as "test1234"
    When user clicks on sublit button
    Then user gets logged to E commerce app



  Scenario: Validate Search Product Electronic
    And user searches for mobile phone
    And user add that phone to cart
    Then user proceeds for payment

  Scenario: Validate Search Product Lifestyle
    And user searches for sandwich maker
    And user add that sandwich maker to cart
    Then user proceeds for payment

  Scenario: Validate Search Product Footwear
    And user searches for sports shoes
    And user add that sports shoes to cart
    Then user proceeds for payment
