Feature: Search product functionality

  Scenario Outline: Validate Search product functionality
    Given user opens the web application
    And user eneters the "<username>"
    And user enters the "<password>"
    When user clicks on submit button
    Then user will be navigated to home page
    And user searches for Mobile phones
    And user add one mobile phone to cart
    Then user proceeds for payment

    Examples: 
      | username | password  |
      | testa    | test@1234 |
      | testb    | test@5678 |
