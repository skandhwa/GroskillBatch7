package StepDefinition5;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition5 {
	
	
	@Before(order=1)
	public void connectToDB()
	{
		System.out.println("Connect to DB");
	}
	
	@Before(order=2)
	public void apiCall()
	{
		System.out.println("calling API");
	}
	
	
	
	@After
	public void DisconnectToDB()
	{
		System.out.println("DisConnect to DB");
	}
	
	@After
	public void closeapiCall()
	{
		System.out.println("closing API call");
	}
	
	
	@Before("@smoke")
	public void onlyBeforeSmoke()
	{
		System.out.println("Before Smoke");
	}
	
	@After("@smoke")
	public void onlyAfterSmoke()
	{
		System.out.println("After Smoke");
	}
	
	
	
	@Given("user opens the web application")
	public void user_opens_the_web_application() {
		
		System.out.println("App open ");
	    
	}

	@Given("user eneters the username")
	public void user_eneters_the_username() {
		
		System.out.println("uname entered");
	    
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
		
		System.out.println("pwd entered");
	    
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
		
		System.out.println("submit clicked");
	    
	}

	@Then("user will be navigated to home page")
	public void user_will_be_navigated_to_home_page() {
		
		System.out.println("Home page navigated");
	    
	}
	
	@When("the user id and password is wrong")
	public void the_user_id_and_password_is_wrong() {
		
		System.out.println("uname and pwd entered is wrong");
	   
	}

	@Then("user will be displayed an error message")
	public void user_will_be_displayed_an_error_message() {
		
		System.out.println("error message displayed");
	   
	}
	
	

@Given("user eneters the {string}")
public void user_eneters_the(String string) {
	
	System.out.println("Username enetered");
    
}

@Given("user enters the {string}")
public void user_enters_the(String string) {
	
	System.out.println("A");
   
}

@Then("user searches for Mobile phones")
public void user_searches_for_mobile_phones() {


	System.out.println("B");
}

@Then("user add one mobile phone to cart")
public void user_add_one_mobile_phone_to_cart() {
    
	System.out.println("C");
}

@Then("user proceeds for payment")
public void user_proceeds_for_payment() {
	
	System.out.println("D");
   
}


@Given("user opens the ecommerce app")
public void user_opens_the_ecommerce_app() {
	
	System.out.println("E");
   
}

@Given("user enters username as {string}")
public void user_enters_username_as(String string) {
	
	System.out.println("F");
   
}

@Given("user enters password as {string}")
public void user_enters_password_as(String string) {
	
	System.out.println("G");
    
}

@When("user clicks on sublit button")
public void user_clicks_on_sublit_button() {
	
	System.out.println("H");
   
}

@Then("user gets logged to E commerce app")
public void user_gets_logged_to_e_commerce_app() {
	
	System.out.println("I");
   
}

@Then("user searches for mobile phone")
public void user_searches_for_mobile_phone() {
	
	System.out.println("J");
   
}

@Then("user add that phone to cart")
public void user_add_that_phone_to_cart() {
	
	System.out.println("K");
    
}

@Then("user searches for sandwich maker")
public void user_searches_for_sandwich_maker() {
	
	System.out.println("L");
   
}

@Then("user add that sandwich maker to cart")
public void user_add_that_sandwich_maker_to_cart() {
	
	System.out.println("M");
   
}

@Then("user searches for sports shoes")
public void user_searches_for_sports_shoes() {
	
	System.out.println("N");
    
}

@Then("user add that sports shoes to cart")
public void user_add_that_sports_shoes_to_cart() {
	
	System.out.println("O");
    
}


@Given("user enters the details in below format")
public void user_enters_the_details_in_below_format(io.cucumber.datatable.DataTable userdata) 
{
	  List<List<String>> data= userdata.asLists(String.class);
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://demo.automationtesting.in/Register.html");
	  driver.manage().window().maximize();
	  driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[1]/input")).sendKeys(data.get(1).get(0));
	  driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input")).sendKeys(data.get(1).get(1));
	  driver.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea")).sendKeys(data.get(1).get(2));
	  driver.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys(data.get(1).get(3));
	//  driver.findElement(By.xpath("//*[@id=\"eid\"]/input")).sendKeys(data.get(1).get(4));
	
	
}
	

}
