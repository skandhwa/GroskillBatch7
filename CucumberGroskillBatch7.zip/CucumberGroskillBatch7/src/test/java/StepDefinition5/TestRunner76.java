package StepDefinition5;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions

(
	features="src/test/java/FeatureFiles/",
	glue= {"StepDefinition5"},
	tags="@smoke",
	dryRun=false,
	monochrome=false,
	
	plugin = {"pretty","html:target/HTMLReports/index.html"}
	
	
		
		
		
		)





















public class TestRunner76 {
	
	
	
	

}
