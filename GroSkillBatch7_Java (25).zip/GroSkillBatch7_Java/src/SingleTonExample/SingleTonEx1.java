package SingleTonExample;



class Singleton3
{
	private static Singleton3 obj1;
	
	private Singleton3()
	{
		System.out.println("Instance created for class");
	}
	
	public static Singleton3 getInstance()
	{
		if(obj1==null)
		{
			obj1=new Singleton3();
		}
		
		return obj1;
	}
	
	
	
	public void test()
	{
		System.out.println("I am singleton method");
	}
	
	
}



public class SingleTonEx1 {

	public static void main(String[] args) {
		
		
		Singleton3.getInstance().test();
		
		

	}

}
