package Java8Topics;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPIEx1 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(12);
		li.add(5);
		li.add(23);
		li.add(49);
		li.add(7);
		li.add(6);
		
		
		//List<Integer> li2=new ArrayList<Integer>();
		
//		for(Integer x:li)
//		{
//			if(x%2==0)
//			{
//				li2.add(x);
//			}
//		}
//		
//		for(int y:li2)
//		{
//			System.out.println(y);
//		}
//		
		
		Stream<Integer> st=li.stream();
		
		
		List<Integer> li2=st.filter(x->x%2==0).collect(Collectors.toList());
		System.out.println(li2);
		
		
	
		

	}

}
