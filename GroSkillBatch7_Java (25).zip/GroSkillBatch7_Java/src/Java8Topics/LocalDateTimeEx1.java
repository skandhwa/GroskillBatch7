package Java8Topics;

import java.time.LocalDate;

public class LocalDateTimeEx1 {

	public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        System.out.println("Today: " + today);

        LocalDate specificDate = LocalDate.of(2026, 6, 29);
        System.out.println("Specific Date: " + specificDate);


	}

}
