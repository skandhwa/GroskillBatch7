package Java8Topics;


interface I5
{
	public int sum(int a,int b,int c,int d);
}

//class A5 implements I5
//{
//	public int sum(int a,int b,int c,int d)
//	{
//		 c=a+b;
//		 d=a+b+c;
//		 return d;
//		
//	}
//}




public class UsingLambdaExpression4 {

	public static void main(String[] args) {
		
		
I5 ref=		(a,b,c,d)->
		{
			c=a+b;
			d=a+b+c;
			return d;
		};
		
		
	System.out.println(ref.sum(12, 67, 90, 108));	
		

	}

}
