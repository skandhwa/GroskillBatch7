package Java8Topics;

@FunctionalInterface
interface I2
{
	void test();
}

 


public class UsingLambdaExpression2 {

	public static void main(String[] args) {
		
		I2 ref=	()-> System.out.println("Hello");
		ref.test();
		

	}

}
