package Java8Topics;

@FunctionalInterface
interface I3
{
	int getStringLength(String str);
}

//class A3 implements I3
//{
//	public int getStringLength(String str)
//	{
//		return str.length();
//	}
//}


public class UsingLambdaExpression3 {

	public static void main(String[] args) {
		
		
		I3 ref=	(str)->str.length();
	System.out.println(ref.getStringLength("India"));	
		
		

	}

}
