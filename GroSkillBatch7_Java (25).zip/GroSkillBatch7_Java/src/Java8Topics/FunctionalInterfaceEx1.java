package Java8Topics;

@FunctionalInterface
interface I7
{
	public  int diff(int a,int b);
	static void msg()
	{
		System.out.println("How r u");
	}
	
	
	
	private void test1()
	{
		System.out.println("Java is robust");
	}
	
	default void test()
	{
		System.out.println("Hello");
		test1();
	}
	
}


public class FunctionalInterfaceEx1 {

	public static void main(String[] args) {
		
		
		I7.msg();
		
	I7 ref=	(a,b)-> a+b;
	
System.out.println(ref.diff(23, 10));	
		
		ref.test();
	
		
		
		
		

	}

}
