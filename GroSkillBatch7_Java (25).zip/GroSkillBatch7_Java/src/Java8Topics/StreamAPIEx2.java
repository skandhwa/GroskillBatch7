package Java8Topics;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamAPIEx2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("India");
		li.add("Nepal");
		li.add("USA");
		li.add("Indonesia");
		li.add("Netherland");
		li.add("Norway");
		li.add("China");
		li.add("India");
		li.add("USA");
		
		Stream<String> st=li.stream();
		List<String> li2 = li.stream()
		        .map(s -> s.toUpperCase())
		        .collect(Collectors.toList());

		System.out.println(li2);
		
		List<String> li3 = li.stream()
		        .map(s -> s.substring(1, 3))
		        .collect(Collectors.toList());
		
		System.out.println(li3);
		
		
		List<String> li4 = li.stream().sorted()
		        .collect(Collectors.toList());

		System.out.println(li4);
		
		
		li.stream()
		  .forEach(s -> System.out.println(s));
		
		
		List<String> li5 = li.stream()
		        .limit(3)
		        .collect(Collectors.toList());

		System.out.println(li5);

		
		List<String> li6 = li.stream()
		        .skip(2)
		        .collect(Collectors.toList());

		System.out.println(li6);
		
		List<String> li7 = li.stream()
		        .distinct()
		        .collect(Collectors.toList());

		System.out.println(li7);
		
		long count = li.stream()
		        .filter(s -> s.startsWith("N"))
		        .count();
		
		System.out.println("Total elements starting from N are  "+count);

		
		
		boolean result = li.stream()
		        .anyMatch(s -> s.startsWith("X"));

		System.out.println(result);
		
		boolean result1 = li.stream()
		        .allMatch(s -> s.length() > 2);

		System.out.println(result1);
		
		Optional<String> val = li.stream()
		        .filter(s -> s.startsWith("N"))
		        .findFirst();

		System.out.println(val.get());


	

		Optional<String> result2 = li.stream()
		        .reduce((a, b) -> a + ", " + b);

		System.out.println(result2.get());
		
		List<String> li9 = li.stream()
		        .filter(s -> s.startsWith("N"))
		        .map(s -> s.toUpperCase())
		        .sorted()
		        .collect(Collectors.toList());

		System.out.println(li9);
		
		
		Set<String> set = li.stream()
		        .collect(Collectors.toSet());

		System.out.println(set);



		

		

		


		
		

	}

}
