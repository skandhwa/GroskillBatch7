package Java8Topics;

@FunctionalInterface
interface I1
{
	public int sum(int a,int b);
	
	
}

//class A implements I1
//{
//	public int sum(int a,int b)
//	{
//		return a+b;
//	}
//}

public class UsingLambdaExpression {

	public static void main(String[] args) {
		
	I1 ref=(a,b) -> a+b;
	
   System.out.println(ref.sum(12, 78));	
		
		
		

	}

}
