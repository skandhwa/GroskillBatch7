package ComparableComparatorEx1;

import java.util.ArrayList;
import java.util.Collections;

class Movie implements Comparable<Movie>
{
	private String name;
	private double rating;
	private int year;
	
	public Movie(String name,double rating,int year)
	{
		this.name=name;
		this.rating=rating;
		this.year=year;
	}
	
	
//	public int compareTo(Movie m) 
//	{
//		return this.year-m.year;
//		
//	}
	
	
	public int compareTo(Movie m) 
	{
	    return Double.compare(this.rating, m.rating);
	}
	
//	@Override
//	public int compareTo(Movie m) 
//	{
//	    return this.name.compareTo(m.name);
//	}


	public String getName() {
		return name;
	}

	public double getRating() {
		return rating;
	}

	public int getYear() {
		return year;
	}


	
	
	
	
}
public class ComparableEx1 {

	public static void main(String[] args) {
		
		
		ArrayList<Movie> li=new ArrayList<>();
		li.add(new Movie("Dangal",4.5,2016));
		li.add(new Movie("Dhurandhar",9.5,2026));
		li.add(new Movie("Raees",3.5,2018));
		li.add(new Movie("Krissh",8.5,2010));
		
		Collections.sort(li);
		
		System.out.println("Movies list after sorting is::");
		for(Movie y:li)
		{
			System.out.println(y.getName()+"   "+y.getRating()+"   "+y.getYear());
		}
		
		

	}

}
