package JavaProgramInterviewImp;

public class TomorrowCode {

	public static void main(String[] args) {
		
		String str="tomorrow";
		char toreplace='o';
		StringBuilder sb=new StringBuilder();
		String replacement="$";
		int count=1;//3
		
		char []ch=str.toCharArray();
		
		for(char x:ch)
		{
			if(x==toreplace)
			{
				sb.append(replacement.repeat(count));
				count ++;
			}
			
			else
			{
				sb.append(x);
			}
			
		}
		
		System.out.println(sb.toString());
		
		

	}

}
