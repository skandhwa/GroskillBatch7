package JavaProgramInterviewImp;

import java.util.LinkedHashSet;
import java.util.Set;

public class FirstNonRepeatedCharacter {

	public static void main(String[] args) {
		
		String str="madam";
		
		Set<Character> s1=new LinkedHashSet<Character>();
		Set<Character> s2=new LinkedHashSet<Character>();
		
		char []ch=str.toCharArray();
		
		for(char x:ch)
		{
			if(!s2.add(x))
			{
				s1.add(x);
			}
		}
		
		
		for(char y:s2)
		{
			if(!s1.contains(y))
				
			{
				System.out.println(y);
				break;
			}
		}
		
		

	}

}
