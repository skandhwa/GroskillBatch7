package JavaProgramInterviewImp;

import java.util.HashSet;
import java.util.Set;

public class LongestSubStringWithoutRepeat {

	public static void main(String[] args) {
		
		
		
		String str = "dabcabcbbefgtyu";
		int max = 0;

		for (int i = 0; i < str.length(); i++) //0<9
		{
		    Set<Character> set = new HashSet<>();

		    for (int j = i; j < str.length(); j++) ///j=0,0<9//j=1//j=2//j=3
		    {
		        char ch = str.charAt(j);///

		        if (set.contains(ch)) 
		        {
		            break;
		        }

		        set.add(ch);
		        max = Math.max(max, set.size());//max=Math.max(0,1)=1//max=Math.max(1,2)=2//
		    //max=Math.max(2,3)=3
		    
		    }
		    
		    
		}

		System.out.println(max);
		
		
		
		
		
		
		

	}

}
