package WrapperClassEx;

public class StringConversionEx {

	public static void main(String[] args) {
		
		String s="250";
		
		int num=Integer.parseInt(s);
		
		System.out.println(num);
		

	}

}
