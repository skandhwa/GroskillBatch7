package WrapperClassEx;

public class ValueOfEx {

	public static void main(String[] args) {
		
		
		int num=100;
		
		Integer x=Integer.valueOf(num);
		
		System.out.println(x);
		
		
		
		

	}

}
