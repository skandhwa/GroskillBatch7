package WrapperClassEx;

public class ConvertPrimitiveToObject {

	public static void main(String[] args) {
		
		int a=10;
		
		Integer obj= Integer.valueOf(a);
		
		System.out.println(obj);
		
		
		int x=obj.intValue();
		
		System.out.println(x);
		
		
		

	}

}
