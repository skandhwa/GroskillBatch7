package WrapperClassEx;

public class IntToString {

	public static void main(String[] args) {
	
		int x=250;
		
		String str=Integer.toString(x);
		
		System.out.println(str);
		

	}

}
