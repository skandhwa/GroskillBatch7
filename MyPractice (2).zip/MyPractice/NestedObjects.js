const student={

"name":"harry",
address:{
"city":"delhi",
"zip":713304

}


}

console.log(student.address.zip)