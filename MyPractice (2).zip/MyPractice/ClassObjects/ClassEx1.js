class Person
{
       constructor(name,age)
       {
        this.name=name
        this.age=age
       }

       display()
       {
        console.log(`Name is  ${this.name}`)
        console.log(`Age is  ${this.age}`)

       }




}

let p1=new Person("Harry",60)
p1.display()