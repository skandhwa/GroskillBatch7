class Birds
{

fly()
{
    console.log("Birds fly")
}
eat()
{
    console.log("Birds eat")
}



}

class Eagle extends Birds
{
     fly()
     {
        console.log("Eagles fly")
     }

     swim()
     {
        console.log("Some eagles can swim")
     }

     display()
     {
        this.fly()
        super.fly()
        super.eat()
        this.swim()
     }


  

}

let obj=new Eagle();
obj.display()

