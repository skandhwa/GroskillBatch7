class X2
{
    static add(a,b)
    {
        return a+b
    }
}

console.log  (X2.add(20,30));