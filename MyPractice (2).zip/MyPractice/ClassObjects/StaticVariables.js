class X3
{
    static companyName="TCS"
    
    constructor(name)
    {
        this.name=name;
    }


    display()
    {
        console.log(`Name is ${this.name}`)
        console.log(X3.companyName)
    }


}


let obj=new X3("Manish");
let obj1=new X3("Harry");

obj.display();
obj1.display();

