class X1
{

    X1()
    {
        console.log("Hello")
    }

     add(a,b)
     {
        return a+b
     }

     mul(a,b)
     {
        return a*b
     }

}

let obj=new X1()
 console.log (obj.add(20,30)  )
   console.log ( obj.mul(40,34))


