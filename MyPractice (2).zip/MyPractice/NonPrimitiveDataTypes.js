let employee={
 
    "name":"harry",
    age:30,
    role:"manager"


}

console.log(employee)

delete employee.role

console.log(employee)


const person={

"name":"tom",
display:function()
{
    console.log("hey how r u")
}


};
person.display();
console.log(person)