const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: false });
  const page = await browser.newPage({
    viewport: { width: 1440, height: 1200 },
  });

  try {
    await page.goto('https://demo.automationtesting.in/Register.html', {
      waitUntil: 'networkidle',
    });

    await page.getByPlaceholder('First Name').fill('John');
    await page.getByPlaceholder('Last Name').fill('Doe');
    await page.locator('textarea[ng-model="Adress"]').fill('123 Main Street, New York');
    await page.getByPlaceholder('Email address').fill('john.doe@example.com');
    await page.getByPlaceholder('Phone').fill('9876543210');

    await page.getByLabel('Male').check();
    await page.getByLabel('Cricket').check();
    await page.getByLabel('Movies').check();

    await page.locator('#Skills').selectOption({ label: 'Java' });
    await page.locator('#countries').selectOption({ label: 'India' });
    await page.locator('#yearbox').selectOption({ label: '1995' });
    await page.locator('#monthbox').selectOption({ label: 'January' });
    await page.locator('#daybox').selectOption({ label: '10' });

    const password = page.locator('input[ng-model="Password"]');
    if (await password.count()) {
      await password.fill('Pass@1234');
    }

    const confirmPassword = page.locator('input[ng-model="CPassword"]');
    if (await confirmPassword.count()) {
      await confirmPassword.fill('Pass@1234');
    }

    await page.locator('#submitbtn').click();

    console.log('Registration form filled successfully.');
  } catch (error) {
    console.error('Test failed:', error);
    throw error;
  } finally {
    await browser.close();
  }
})();
