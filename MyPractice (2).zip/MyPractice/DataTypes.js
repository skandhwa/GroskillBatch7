let x=30
console.log(x)

let str="harry"
console.log(str)

let b = BigInt("0b1010101001010101001111111111111111");
console.log(b);

let n3 = Infinity;
console.log(n3)

let flag=true
 console.log(flag)

let address;
console.log(address)

let val=null
console.log(val)


let s1 = Symbol("Geeks");
let s2 = Symbol("Geeks");
console.log(s1 == s2);

let m="hi"
let n="hi"
console.log(m==n)


let id=Symbol()
console.log(id)
let p=Symbol("id")
console.log(p)