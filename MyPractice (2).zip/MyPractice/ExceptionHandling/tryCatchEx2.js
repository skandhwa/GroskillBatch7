try{

    console.log(r)
}

catch(error)
{
    console.log(error.message)
}
