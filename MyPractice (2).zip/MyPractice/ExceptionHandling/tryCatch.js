try{

    let r=100/0
    //console.log(r)
}

catch(error)
{
    console.log(error.message)
}

// let a=20,b=30;
// let c=a+b
// console.log(c)