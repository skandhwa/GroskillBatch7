try{

let n=null
 console.log(n.name)

}

catch(error)
{
    console.log(error.message)
}

let a=20,b=30
let c=a+b
console.log(c)