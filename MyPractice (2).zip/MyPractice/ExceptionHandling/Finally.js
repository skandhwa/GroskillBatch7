try

{

console.log("Try block")
throw new Error("Error occured")

}

// catch(error)
// {
//     console.log("Catch block ",error.message)
// }


finally
{
    console.log("Always executes")
}
