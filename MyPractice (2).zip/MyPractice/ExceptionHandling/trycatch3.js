let r=20/0
console.log(r)
let a=20,b=30
let c=a+b
console.log(c)

