let fruits=["Apple","Guava","Mango","Kiwi"]
console.log(fruits.join("-"))

