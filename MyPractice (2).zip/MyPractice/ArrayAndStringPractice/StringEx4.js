// let str="Hello"

// console.log(str.at(-2))



// let str="Hello JavaScript"

// console.log(str.includes("Hello"))

let str="tip  toe tap"

let r=str.split(" ")

console.log(str.repeat(3))

//console.log(r[2])






