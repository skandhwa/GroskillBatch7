let x="javascript"

console.log(x.substring(-5))


console.log(x.slice(4))

//console.log(x.slice(2,5));

