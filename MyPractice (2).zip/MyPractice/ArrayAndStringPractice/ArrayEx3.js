let fruits=["Mango","Apple","Guava","Kiwi"]
fruits.splice(1,2)
console.log(fruits)
let y=fruits.indexOf("Kiwi")
console.log(y)