let fruits=["Mango","Apple","Guava","Kiwi","Mango","Apple"]

let y=fruits.lastIndexOf("Mango")

console.log(y)

let z=fruits.includes("Guava")
console.log(z)
