let x="Saurabh";
let len=x.length;

console.log(len)

let y=x.charAt(3)

console.log(y)

