let num=[10,20,30,40,50]

let r=num.filter(num=>num>50)

console.log(r)