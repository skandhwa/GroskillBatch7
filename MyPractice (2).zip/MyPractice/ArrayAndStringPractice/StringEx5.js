let num=100

let r= String(num)

console.log(r)

console.log(typeof (num))

let na="Jack"

let age=50

console.log(`My name is ${na} and age is ${age}`)