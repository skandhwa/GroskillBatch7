let num=[10,20,30,40,50]
let r=num.find(num =>num>30)
console.log(r)

let s=num.findIndex(num=>num>10)
console.log(s)
