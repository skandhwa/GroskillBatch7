let p= new Promise((resolve,reject)=> {

    let flag=true

    if(flag)
    {
        resolve("Operation Successfull")
    }
    else{
        reject("Operation failure")
    }


})

p.then((result) =>
{

    console.log(result)
})