async function getData()
{
    let response= await ("https://www.google.com")
    
    let data=await response.json();

    console.log(data)


}

test().then (result => 

    {
        console.log(result)

    }


)