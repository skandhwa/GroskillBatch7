let employee={
 
    
    "name":"harry",
    age:30,
    role:"manager"
    


}

for(let x in employee)
{
    console.log(x,employee[x])
}