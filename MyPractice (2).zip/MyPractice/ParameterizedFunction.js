function show(name)
{
    console.log("Hello "+name)
}

show("Saurabh")