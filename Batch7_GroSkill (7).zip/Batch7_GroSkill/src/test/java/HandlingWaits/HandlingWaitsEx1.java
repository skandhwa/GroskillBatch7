package HandlingWaits;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingWaitsEx1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
	
		
		////Implicit Wait 
		
		//Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		
		///Explicit Wait
		
		WebDriverWait x= new WebDriverWait(driver,Duration.ofSeconds(10));
		
		
		
		

	}

}
