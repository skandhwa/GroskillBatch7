package MyBasics;

public class OperatorsJava {

	public static void main(String[] args) {
		
//		int a=5;
//		
//		int b=a++  + ++a ;
//		
//		// 5 + 7
//		
//		//a=6
//		
//		System.out.println(b);
		
		
	int x=10,y=10,z=7;
	
	int r= x++  + ++y + z++  + ++x - --y - --z;
	
	/// int r =10+ 11 + 7 +12 - 10 - 7
	
	////x= 11 , y=11 , z=8 ,
	
	
	System.out.println(r);
	
	int p=23%3;
	
	System.out.println(p);
	
		
		
		

	}

}
