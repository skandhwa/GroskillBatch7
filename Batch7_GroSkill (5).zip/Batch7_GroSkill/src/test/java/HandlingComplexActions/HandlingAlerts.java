package HandlingComplexActions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.findElement()
		

	}

}
