package POJOEx1;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import RestAssuredPractice.PayloadData;
import io.restassured.RestAssured;

public class CreateEmployee1 {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		EmployeePOJO1 empPOJO=new EmployeePOJO1();
		empPOJO.setName("Harry");
		empPOJO.setJob("QA Lead");
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empPOJO);
		
		
	RestAssured.baseURI="https://reqres.in";
	
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON)
		
		.when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201)
		.extract().response().asString();
	
	
	System.out.println(Response);
		
		
		

	}

}
