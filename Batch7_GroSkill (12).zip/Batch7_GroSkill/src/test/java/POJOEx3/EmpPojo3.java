package POJOEx3;

import java.util.List;

public class EmpPojo3 {
	
	private String name;
	private int age;
	private double salary;
	private EmpAddressPOJO empAddress;
	private List<String> banks;
	private boolean isMarried;
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public double getSalary() {
		return salary;
	}
	public EmpAddressPOJO getEmpAddress() {
		return empAddress;
	}
	public List<String> getBanks() {
		return banks;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setEmpAddress(EmpAddressPOJO empAddress) {
		this.empAddress = empAddress;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	

}
