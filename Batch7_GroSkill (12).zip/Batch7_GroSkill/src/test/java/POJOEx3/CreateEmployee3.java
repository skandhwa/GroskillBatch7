package POJOEx3;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		List<String> li=new ArrayList<String>();
		li.add("AK Gym");
		li.add("CK sweets");
		li.add("PT stores");
		
		
		HouseDetailsPOJO hdPojo=new HouseDetailsPOJO();
		hdPojo.setFlatNo(45);
		hdPojo.setAppartName("GK Appt");
		hdPojo.setStreet("MG road");
		hdPojo.setLandmark(li);
		
		
		EmpAddressPOJO empAdd=new EmpAddressPOJO();
		empAdd.setHdPojo(hdPojo);
		empAdd.setCity("Delhi");
		empAdd.setState("NCR");
		empAdd.setZip(876543);
		
		
		List<String> banks=new ArrayList<String>();
		banks.add("HDFC");
		banks.add("SBI");
		banks.add("Axis");
		
		EmpPojo3 emp=new EmpPojo3();
		emp.setName("Harry");
        emp.setSalary(90000);
        emp.setMarried(false);
        emp.setAge(43);
        emp.setEmpAddress(empAdd);
        emp.setBanks(banks);
        
        ObjectMapper obj=new ObjectMapper();
        
    String empJSOn=    obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
    RestAssured.baseURI="https://reqres.in";
	
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSOn)
		
		.when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201)
		.extract().response().asString();
	
	
	System.out.println(Response);
		
		
		
	}

}
