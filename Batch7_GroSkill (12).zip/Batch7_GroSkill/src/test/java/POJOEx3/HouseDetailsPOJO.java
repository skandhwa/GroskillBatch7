package POJOEx3;

import java.util.List;

public class HouseDetailsPOJO {
	
	private int flatNo;
	private String street;
	private List<String> landmark;
	private String appartName;
	
	public int getFlatNo() {
		return flatNo;
	}
	public String getStreet() {
		return street;
	}
	public List<String> getLandmark() {
		return landmark;
	}
	public String getAppartName() {
		return appartName;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public void setLandmark(List<String> landmark) {
		this.landmark = landmark;
	}
	public void setAppartName(String appartName) {
		this.appartName = appartName;
	}
	
	
	
	
	
	

}
