package POJOEx3;

public class EmpAddressPOJO {
	
	private HouseDetailsPOJO hdPojo;
	private int zip;
	private String state;
	private String city;
	public HouseDetailsPOJO getHdPojo() {
		return hdPojo;
	}
	public int getZip() {
		return zip;
	}
	public String getState() {
		return state;
	}
	public String getCity() {
		return city;
	}
	public void setHdPojo(HouseDetailsPOJO hdPojo) {
		this.hdPojo = hdPojo;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	

}
