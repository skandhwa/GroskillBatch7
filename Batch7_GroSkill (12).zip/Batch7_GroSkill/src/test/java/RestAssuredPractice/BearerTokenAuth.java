package RestAssuredPractice;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class BearerTokenAuth {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://gorest.co.in";
		
		String email = "tom" + ((int)(Math.random() * 1000000)) + "@gmail.com";
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name", "john");
		mp.put("gender", "male");
		mp.put("email", email);
		mp.put("status", "active");
		mp.put("isMarried", false);
		
		String token ="Bearer a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";
		
		String Response=	given().log().all().headers("Authorization",token)
				.header("content-type","application/json").body(mp)
				
				.when().post("public/v2/users")
				.then().assertThat().statusCode(201)
				.extract().response().asString();
			
			System.out.println(Response);
		
		
		

	}

}
