package RestAssuredPractice;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class MyPracticeTest2 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
String Response=		given().log().all().queryParam("page",2)
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		
		.when().get("api/users")
		
		.then().log().all().
		assertThat().statusCode(200).extract().response().asString();


System.out.println(Response);

JsonPath js=new JsonPath(Response);
String firstName=js.getString("data[0].first_name");

Assert.assertEquals("Michael", firstName);



		
		

	}

}
