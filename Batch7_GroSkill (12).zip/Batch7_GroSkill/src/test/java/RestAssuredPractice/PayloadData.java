package RestAssuredPractice;

public class PayloadData {
	
	public static String getData(String name,String jobRole)
	{
		
		String empData="{\r\n"
				+ "   \"name\":\""+name+"\",\r\n"
				+ "   \"job\":\" "+jobRole+"\"\r\n"
				+ "\r\n"
				+ "}";
		
		return empData;
		
	}
	

}
