package RestAssuredPractice;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class MyPracticeTest1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
		when().get("api/users").
		then().log().all().assertThat().statusCode(200).extract().response().asString();
		
	
	System.out.println(Response);
		
		

	}

}
