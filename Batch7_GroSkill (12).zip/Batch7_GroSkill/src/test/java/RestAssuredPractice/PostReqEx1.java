package RestAssuredPractice;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class PostReqEx1 {

	public static void main(String[] args) {
		
		int id1=921;
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(PayloadData.getData("John","Analyst"))
		
		.when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201)
		.extract().response().asString();
	
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	int id=js.getInt("id");
	
	Assert.assertEquals(id,id1 );
	String val=js.getString("_meta.docs_url");
	
	Assert.assertEquals("https://app.reqres.in/documentation", val);
	
	
	
	
	
	
	
		

	}

}
