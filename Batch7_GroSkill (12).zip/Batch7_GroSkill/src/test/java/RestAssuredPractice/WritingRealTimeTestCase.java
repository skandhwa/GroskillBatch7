package RestAssuredPractice;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class WritingRealTimeTestCase {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(ResponsePayload.coursePayload());
		
		
		//// Print No of courses returned by API
		
		int courseSize=js.getInt("courses.size()");
		System.out.println("Total size of courses are  "+courseSize);
		
		/// Print Purchase Amount

		int amount=js.getInt("dashboard.purchaseAmount");
		System.out.println("Total Purchase Amount is  "+amount);
		
		
		/// Print Title of the first course

	String courseTitle=	js.getString("courses[0].title");
	System.out.println("Title of first course is  "+courseTitle);
	
	//  Print All course titles and their respective Prices

	System.out.println("Course title and their prices are ");
	
	for(int i=0;i<courseSize ;i++)
	{
		String title=js.getString("courses["+i+"].title");
		
		int price=js.getInt("courses[" +i+"].price");
		
		System.out.println(title+"  "+price);
		
		
	}
	
		
	//// Print no of copies sold by RPA Course
	
	for(int i=0;i<courseSize ;i++)
	{
		String title=js.getString("courses["+i+"].title");
		
		if(title.equalsIgnoreCase("RPA"))
		{
			int copies=js.getInt("courses["+i+"].copies");
			System.out.println("Total copies of RPA  are  "+copies);
			
		}
		
		
		
	}
		
	///  Verify if Sum of all Course prices matches with Purchase Amount

	int sum=0;
	for(int i=0;i<courseSize;i++)
	{
	  int price=	js.getInt("courses["+i+"].price");
		
	  int copies=  js.getInt("courses["+i+"].copies");
	  
	  int courseAmount=price*copies;
	  
	  sum=sum+courseAmount;
	  
	  
	}
	
	System.out.println("Total sum amount for all courses is  "+sum);

		
		Assert.assertEquals(sum, amount);
		
		
		System.out.println("ALl test cases passed");
		

	}

}
