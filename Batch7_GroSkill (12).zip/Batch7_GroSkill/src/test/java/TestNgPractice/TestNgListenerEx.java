package TestNgPractice;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestNgListenerEx implements ITestListener {
	
	public static WebDriver driver;

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSuccess(result);
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		  Object currentClass = result.getInstance();
		    WebDriver driver = ((BaseTest) currentClass).driver;

		    File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		    try {
		        FileUtils.copyFile(src,
		                new File("E:\\ScreenShot14thJuly\\" + result.getName() + ".png"));
		    } catch (IOException e) 
		    {
		        e.printStackTrace();
	}
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSkipped(result);
	}
	
	
	
	

	

}
