package POJOEx2;

public class EmpAddressPOJO1 {
	
	private int zip;
	private String state;
	private String city ;
	
	public int getZip() {
		return zip;
	}
	public String getState() {
		return state;
	}
	public String getCity() {
		return city;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
	
	

}
