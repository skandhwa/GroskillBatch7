package POJOEx2;

import static io.restassured.RestAssured.given;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmpAddressPOJO1 empAdd=new EmpAddressPOJO1();
		empAdd.setCity("Kolkata");
		empAdd.setState("WB");
		empAdd.setZip(700054);
		
		
		EmployeePOJO2 empPojo=new EmployeePOJO2();
		empPojo.setName("Tom");
		empPojo.setAge(35);
		empPojo.setSalary(90000);
		empPojo.setMarried(true);
		empPojo.setEmpAdd(empAdd);
		
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empPojo);
		
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
			.body(empJSON)
			
			.when().post("api/users")
			
			.then().log().all().assertThat().statusCode(201)
			.extract().response().asString();
		
		
		System.out.println(Response);
			
		
		
		
		
		

	}

}
