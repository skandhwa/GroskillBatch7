package POJOEx2;

public class EmployeePOJO2 {
	
	private String name;
	private int age;
	private double salary;
	private EmpAddressPOJO1 empAdd;
	private boolean isMarried;
	
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public double getSalary() {
		return salary;
	}
	public EmpAddressPOJO1 getEmpAdd() {
		return empAdd;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public void setEmpAdd(EmpAddressPOJO1 empAdd) {
		this.empAdd = empAdd;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	
	

}
