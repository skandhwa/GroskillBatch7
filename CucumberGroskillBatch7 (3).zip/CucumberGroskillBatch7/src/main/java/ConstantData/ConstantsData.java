package ConstantData;

public class ConstantsData {
	
	public static final String PROP_FILE_PATH="src/main/java/Global.properties";
	public static final String EXCEL_PATH="src/main/java/TestData/URLPath.xlsx";

}
