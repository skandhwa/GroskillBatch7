package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx1 {

	public static void main(String[] args) {
		
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("banana");
		s1.add(null);
		s1.add("mango");
		s1.add("guava");
		s1.add("melon");
		s1.add("mango");
		s1.add(null);
		
		for(String x:s1)
		{
			System.out.println(x);
		}

	}

}
