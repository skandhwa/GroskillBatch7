package SetPractice;

import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(12);
		s1.add(67);
		s1.add(89);
		s1.add(null);
		
		for(Integer x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("######################################################");
		
		for(Integer y:s1.descendingSet())
		{
			System.out.println(y);
		}
		

	}

}
