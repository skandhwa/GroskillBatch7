package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class FirstNonRepeatingChar {

	public static void main(String[] args) {
		
		int []a= {2,3,4,2,3,4,6};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		Set<Integer> s2=new LinkedHashSet<Integer>();
		
		for(int x:a)
		{
			if(!s1.add(x))
			{
				s2.add(x);
			}
		}
		
		
		for(int y:a)
		{
			if(!s2.contains(y))
			{
				System.out.println("First Non repeating is  "+y);
				break;
			}
		}
		

	}

}
