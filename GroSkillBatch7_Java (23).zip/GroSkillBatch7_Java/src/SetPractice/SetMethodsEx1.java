package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethodsEx1 {

	public static void main(String[] args) {
	
		Set<Object> s1=new LinkedHashSet<Object>();
		s1.add(34);
		s1.add(true);
		s1.add(9800000000L);
		s1.add('A');
		
		for(Object x:s1)
		{
			System.out.println(x);
		}
		
		

	}

}
