package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods3 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("banana");
		s1.add("mango");
		s1.add("guava");
		s1.add("melon");
		
		Set<String> s2=new LinkedHashSet<String>();
		s2.add("kiwi");
		s2.add("orange");
		s2.add("pineapple");
		s2.add("melon");
		
		s1.addAll(s2);
		
		System.out.println(s1);
		
		
		

	}

}
