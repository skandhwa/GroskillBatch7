package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintAllRepeatedCharactersString {

	public static void main(String[] args) {
		
		String str="sssssbbbbcccdefgh";/// s--4, b--3,c--3
		
		char []ch=str.toCharArray();
		
		Set<Character> s1=new LinkedHashSet<Character>();
		
		
		for(char x:ch)
		{
			if(!s1.add(x))
			{
				System.out.println(x);
			}
		}
		
		

	}

}
