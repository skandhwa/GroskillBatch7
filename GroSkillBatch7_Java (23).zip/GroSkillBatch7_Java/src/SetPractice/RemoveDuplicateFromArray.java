package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateFromArray {

	public static void main(String[] args) {
		
		int []a= {12,45,12,78,45,65,43,89};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		
//		for(int x:a)
//		{
//			s1.add(x);
//		}
//		
//		System.out.println(s1);
		
		
		for(int x:a)
		{
			if(!s1.add(x))
			{
				System.out.println(x);
			}
		}
		
		
		
		
		

	}

}
