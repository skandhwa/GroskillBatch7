package SetPractice;

import java.util.TreeSet;

public class TreeSetEx2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(45);
		s1.add(12);
		s1.add(67);
		s1.add(89);
		
		
	System.out.println(s1.first());	
	
	System.out.println	(s1.last());
	
	System.out.println(s1.ceiling(30));
	
	System.out.println(s1.floor(30));
	
	System.out.println(	s1.pollFirst());
		
	System.out.println(	s1.pollLast());
		
		
		
		
		

	}

}
