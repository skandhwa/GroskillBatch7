package SetPractice;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		s1.add("banana");
		s1.add("mango");
		s1.add("guava");
		s1.add("melon");
		
	boolean flag=	s1.contains("mango");
		
		System.out.println("Does the set contains mango "+flag);
		
		s1.remove("guava");
		
		System.out.println(s1);
		
		int x=s1.size();
		
		System.out.println("Size of set is  "+x);
		
		
	
		

	}

}
