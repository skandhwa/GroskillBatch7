package SetPractice;

import java.util.TreeSet;

public class TreeSet3 {

	public static void main(String[] args) {
		
		TreeSet<String> s1=new TreeSet<String>();
		s1.add("A");
		s1.add("B");
		s1.add("C");
		s1.add("D");
		s1.add("E");
		
		
	System.out.println(s1.headSet("B",true));	
		
	System.out.println(s1.tailSet("B",false));	
	
	System.out.println(s1.subSet("A",true,"D", true));
		
		

	}

}
