package CollectionsPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ReverseAndSortArray {

	public static void main(String[] args) {
		
		int []a= {12,45,78,2,4,6};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li1.add(x);
			Collections.sort(li1);
			
			
		}
		
		System.out.println(li1);
		
		
		for(int y:a)
		{
			li2.add(y);
			Collections.reverse(li2);
			
			
		}
		
		System.out.println(li2);
		
		

	}

}
