package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class CollectionsEx5 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("banana");//1024
		li.add("apple");
		li.add("melon");
		li.add("orange");
		
		
		
		//li.remove(3);
		
		li.clear();
		
		System.out.println(li);
		
		List<String> li2=new ArrayList<String>();
		li2.add("kiwi");//1024
		li2.add("mango");
		li2.add("guava");
		li2.add("orange");
		
//		
//		li.removeAll(li2);
//		
//		System.out.println(li);
		
		li.retainAll(li2);
		System.out.println(li);
		

	}

}
