package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class CollectionsEx4 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("banana");//1024
		li.add("apple");
		li.add("melon");
		li.add("orange");
		
		List<String> li2=new ArrayList<String>();
		li2.add("kiwi");//1024
		li2.add("mango");
		li2.add("guava");
		li2.add("orange");
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
	boolean flag=	li.containsAll(li2);
	
	System.out.println("Is all elements of li2 present in li "+flag);
		
		
		
		

	}

}
