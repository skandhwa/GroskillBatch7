package CollectionsPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoveAllZeroToOneEnd {

	public static void main(String[] args) {
		
		int[]a= {7,0,11,0,0,-4,8,0};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		for(int x:a)
		{
			if(x!=0)
			{
				li1.add(x);
				Collections.sort(li1);
				
			}
			else
			{
				li2.add(x);
			}
		}
		
		li1.addAll(li2);
		
		System.out.println(li1);
		
		
		

	}

}
