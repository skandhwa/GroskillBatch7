package CollectionsPractice;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx1 {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		
		q1.add(56);
		q1.add(89);
		q1.add(105);
		
		System.out.println(q1);
		
		q1.remove();
		
		System.out.println(q1);
		
		
		
	}

}
