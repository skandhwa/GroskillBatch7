package CollectionsPractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayToArrayList {

	public static void main(String[] args) {
		
		Integer []a=new Integer[] {4,7,1,3,9};
		
		ArrayList<Integer> li=new ArrayList<>(Arrays.asList(a));
		for(Integer x:li)
		{
			System.out.println(x);
		}
		
		
		
		int []b=new int[] {67,54,32,89};
		List<Integer> li1=new ArrayList<Integer>();
		for(Integer y:b)
		{
			li1.add(y);
		}
		
		System.out.println(li);
		
		
		
		
		
		
		
		
	}

}
