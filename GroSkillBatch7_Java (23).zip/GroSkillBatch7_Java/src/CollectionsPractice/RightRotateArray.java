package CollectionsPractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RightRotateArray {

	public static void main(String[] args) {
		
		int []a= {7,2,5,4,3};
		
		List<Integer> li=new ArrayList<Integer>();
		
		for(int x:a)
		{
			li.add(x);
		}
		
		Collections.rotate(li, -2);
		
		System.out.println(li);
		

	}

}
