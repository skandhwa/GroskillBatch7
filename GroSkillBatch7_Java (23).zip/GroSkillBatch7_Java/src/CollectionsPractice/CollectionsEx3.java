package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class CollectionsEx3 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("banana");//1024
		li.add("apple");
		li.add("melon");
		li.add("orange");
		
	String x=	li.get(2);
		System.out.println(x);
		
		li.set(3, "guava");
		System.out.println(li);
		
	boolean flag=	li.contains("banana");
	
	System.out.println("Does the list contains banana "+flag);
	
	
	li.remove(2);
	
	System.out.println(li);
		

	}

}
