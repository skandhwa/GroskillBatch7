package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class ArrayListToArray {

	public static void main(String[] args) {
		
		
		List<String> li=new ArrayList<String>();
		li.add("banana");//1024
		li.add("apple");
		li.add("melon");
		li.add("orange");
		
//		String []a=li.toArray(new String[0]);
//		
//		for(String x:a)
//		{
//			System.out.println(x);
//		}
		
		String []a=new String[(li.size())];
		
		for(int i=0;i<a.length;i++)
		{
			a[i]=li.get(i);
			System.out.println(a[i]);
			
		}
		
		
		
	}

}
