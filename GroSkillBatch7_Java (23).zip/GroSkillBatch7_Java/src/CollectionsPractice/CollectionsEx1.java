package CollectionsPractice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class CollectionsEx1 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("A");
		li.add("B");
		li.add("C");
		li.add("D");
		
		
//		System.out.println(li);
//		System.out.println("#############################################");
//		
//		for(int x:li)
//		{
//			System.out.println(x);
//		}
//		System.out.println("#############################################");
//		for(int i=0;i<li.size();i++)
//		{
//			System.out.println(li.get(i));
//		}
//		System.out.println("#############################################");
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("#############################################");
		
		ListIterator <String> itr1=li.listIterator(li.size());
		while(itr1.hasPrevious())
		{
			System.out.println(itr1.previous());
		}
		
		

	}

}
