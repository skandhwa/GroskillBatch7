package CollectionsPractice;

import java.util.Stack;

public class BalancedParenthesis {

    public static boolean isBalanced(String str) {
        Stack<Character> stack = new Stack<>();

        for (char ch : str.toCharArray()) {

            
            if (ch == '(' || ch == '{' || ch == '[') 
            {
                stack.push(ch);
            }

           
            else if (ch == ')' || ch == '}' || ch == ']') 
            {

                if (stack.isEmpty()) 
                {
                    return false;
                }

                char top = stack.pop();

                if ((ch == ')' && top != '(') ||
                    (ch == '}' && top != '{') ||
                    (ch == ']' && top != '[')) {
                    return false;
                }
            }
        }

        // Stack should be empty if balanced
        return stack.isEmpty();
    }

    public static void main(String[] args) {
        String input = "{[()]}";

        if (isBalanced(input)) {
            System.out.println("Balanced Parenthesis");
        } else {
            System.out.println("Not Balanced");
        }
    }
}