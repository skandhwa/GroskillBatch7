package CollectionsPractice;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(34);
		stk.push(67);
		stk.push(88);
		stk.push(23);
		
		System.out.println(stk);
		
		stk.pop();
		stk.pop();
		
		System.out.println(stk);

	}

}
