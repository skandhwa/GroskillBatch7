package CollectionsPractice;

import java.util.ArrayList;
import java.util.List;

public class CollectionsEx2 {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add("Harry");
		li.add('A');
		li.add(false);
		li.add(78);
		li.add(78);
		
		for(Object x:li)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
