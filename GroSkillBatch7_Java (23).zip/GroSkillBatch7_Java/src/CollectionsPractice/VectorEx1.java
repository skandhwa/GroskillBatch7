package CollectionsPractice;

import java.util.Vector;

public class VectorEx1 {

	public static void main(String[] args) {
		
		Vector<Integer> v=new  Vector<Integer>();
		v.add(23);
		v.add(98);
		v.add(106);
		v.add(54);
		
		for(Integer x:v)
			
		{
			System.out.println(x);
		}
		

	}

}
