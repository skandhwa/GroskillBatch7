package MapExample;

import java.util.HashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new HashMap<Integer,String>();
		mp.put(1,null);
		mp.put(50,"orange");
		mp.put(7,"papya");
		mp.put(18,null);
		mp.put(2,"kiwi");
		mp.put(null, "pines");
		
		
		System.out.println(mp);
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
			
		}
		
		

	}

}
