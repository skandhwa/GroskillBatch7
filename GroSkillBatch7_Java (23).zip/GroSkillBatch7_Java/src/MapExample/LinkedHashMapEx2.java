package MapExample;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(1,"mango");
		mp.put(50,"orange");
		mp.put(7,"papaya");
		mp.put(18,"melon");
	
		
		Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
		mp2.put(12,"pines");
		mp2.put(18,"banana");
		mp2.put(7,"guava");
		mp2.put(18,"strawberry");
		
		
		mp.putAll(mp2);
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
			
		}
		
		
		mp.remove(18, "strawberry");
		System.out.println("#################################################");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
			
		}
		
		mp.equals(mp2);
		
		
		
		
		
		
	
		
		
		
		

	}

}
