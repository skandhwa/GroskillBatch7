package MapExample;

import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapEx1 {

	public static void main(String[] args) {
		
		Map<Character,String> mp=new LinkedHashMap<Character,String>();
		
		mp.put('A', "apple");
		mp.put('B', "orange");
		mp.put('C', "banana");
		mp.put('D', "melon");
		mp.put('E', "kiwi");
		
		
//		mp.clear();
//		
//		System.out.println(mp);
//		
//		boolean flag3=mp.isEmpty();
//		System.out.println(flag3);
		
	String val=	mp.get('E');
	System.out.println(val);
	
	boolean flag=mp.containsKey('Z');
	System.out.println(flag);
	
	
	boolean flag1=mp.containsValue("kiwi");
	System.out.println(flag1);
	
	
	
	
		
		
		
		
		
	}

}
