package MapExample;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyofWords {

	public static void main(String[] args) {
		
		String str="tip tap toe tip tap tap";
		
		String []s1=str.split(" ");
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
		for(String x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
				
				
				
				
			}
			
			else
			{
				mp.put(x,1);
			}
			
		}
		
		

		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
			
		}
		
		
		String maxElement="";
		String minElement="";
		
		int maxFreq=0,minFreq=Integer.MAX_VALUE;;
		
		
		for(Map.Entry<String,Integer> z:mp.entrySet())
		{
			int freq=z.getValue();///freq=3///freq=2//freq=1
			String element= z.getKey();///element=10///element=20///element=30
			
			if(freq>maxFreq)///
			{
				maxFreq=freq;///
				maxElement=element;////
			}
			
			
			if(freq<minFreq)///3<9999///2<3//1<2
			{
				minFreq=freq;///minFreq=2///minFreq=1
				minElement =element;////minElement=20///minElement=30
			}
			
			
			
		}
		
		
		System.out.println("Max Frequency is "+maxElement+"  "+"--->"+"  "+maxFreq);
		System.out.println("Min Frequency is "+minElement+"  "+"--->"+"  "+minFreq);
		
		
		}
		
		
		

	}


