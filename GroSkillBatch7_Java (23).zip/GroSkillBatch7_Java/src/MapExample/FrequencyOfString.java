package MapExample;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfString {

	public static void main(String[] args) {
		
		String str="mmadam";
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		
		
		char []s1=str.toCharArray();
		
		for(char x:s1)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
				
				
				
				
			}
			
			else
			{
				mp.put(x,1);
			}
			
		}
		
		

		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+"  ");
			System.out.println(x.getValue());
			
		}
		
		
		char maxElement=' ';
		char minElement=' ';
		
		int maxFreq=0,minFreq=9999;
		
		
		for(Map.Entry<Character,Integer> z:mp.entrySet())
		{
			int freq=z.getValue();///freq=3///freq=2//freq=1
			char element= z.getKey();///element=10///element=20///element=30
			
			if(freq>maxFreq)///
			{
				maxFreq=freq;///
				maxElement=element;////
			}
			
			
			if(freq<minFreq)///3<9999///2<3//1<2
			{
				minFreq=freq;///minFreq=2///minFreq=1
				minElement =element;////minElement=20///minElement=30
			}
			
			
			
		}
		
		
		System.out.println("Max Frequency is "+maxElement+"  "+"--->"+"  "+maxFreq);
		System.out.println("Min Frequency is "+minElement+"  "+"--->"+"  "+minFreq);
		
		
		

	}

}
