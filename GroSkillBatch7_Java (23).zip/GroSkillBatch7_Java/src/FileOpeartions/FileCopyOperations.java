package FileOpeartions;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCopyOperations {

	public static void main(String[] args)  {
		
		try (
	            FileInputStream f = new FileInputStream("D:\\File13thJune\\test13thjune.txt");
	            FileOutputStream f1 = new FileOutputStream("D:\\FileData15thJune\\testData15thJune3.txt")
	        ) {

	            int data;

	            while ((data = f.read()) != -1) {
	                f1.write(data);
	            }

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	}

///  D:\\FileData15thJun\\testData15thJune2.txt