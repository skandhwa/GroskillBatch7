package FileOpeartions;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args)  {
		
		
		File f=new File("D:\\File13thJune\\test13thjune.txt");
		
		
		try 
		{
			Scanner sc = new Scanner(f);
		
		
		
		while(sc.hasNextLine())
		{
			System.out.println(sc.nextLine());
			
		}
		
		sc.close();
		
		}
		
		
		catch (FileNotFoundException e) 
		{
			System.out.println("caught with "+e);
		}
		
		
		
		
		
		

	}

}
