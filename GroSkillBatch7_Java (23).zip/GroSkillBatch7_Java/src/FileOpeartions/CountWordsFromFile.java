package FileOpeartions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountWordsFromFile {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br=new BufferedReader(new FileReader("D:\\FileData15thJune\\testData15thJune3.txt"));
		String line;
		int words=0;
		
		while((line=br.readLine())!=null)
		{
			words=words+line.split(" ").length;
		}
		
		System.out.println("Total number of words are  "+words);
		
		
		
	}

}
