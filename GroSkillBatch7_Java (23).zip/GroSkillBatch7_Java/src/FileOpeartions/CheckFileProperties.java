package FileOpeartions;

import java.io.File;

public class CheckFileProperties {

	public static void main(String[] args) {
		
		File f=new File("D:\\File13thJune\\test13thjune.txt");
		
		if(f.exists())
		{
			System.out.println("Name of file is "+f.getName());
			
			System.out.println("Absolute path is  "+f.getAbsolutePath());
		
			
			System.out.println("Is the file readable  "+f.canRead());
			
			System.out.println("Is the file Writtable "+f.canWrite());
			
			System.out.println("Size of file is  "+f.length());
			
			
			
		}
		
		
		
		

	}

}
