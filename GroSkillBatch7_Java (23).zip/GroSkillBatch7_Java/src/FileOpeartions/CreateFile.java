package FileOpeartions;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CreateFile {

	public static void main(String[] args) throws IOException {
		
		File f=new File("D:\\File13thJune\\test13thjune.txt");
	boolean flag=	f.createNewFile();
	
	System.out.println("Is the file created  "+flag);
	
	
	
	FileWriter writer=new FileWriter("D:\\File13thJune\\test13thjune.txt",true);
	writer.write("Saurabh is a trainer");
	writer.close();
	
	
	
	
		

	}

}
