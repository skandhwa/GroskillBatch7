package FileOpeartions;

import java.io.File;
import java.io.IOException;

public class DeleteFile {

	public static void main(String[] args) throws IOException {
		
		
		File f=new File("D:\\File13thJune\\test13thjune.txt");
	boolean flag=	f.createNewFile();
	
	System.out.println("Is the file created  "+flag);
	
	boolean flag1=f.delete();
	
	System.out.println("Is the file deleted  "+flag1);

	}

}
