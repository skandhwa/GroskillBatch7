package FileOpeartions;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadDataBufferedReader {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br= new BufferedReader(new FileReader("D:\\File13thJune\\test13thjune.txt"));
		String line;
		
		while((line=br.readLine())!=null)
		{
			System.out.println(line);
		}
		
		br.close();
		

	}

}
