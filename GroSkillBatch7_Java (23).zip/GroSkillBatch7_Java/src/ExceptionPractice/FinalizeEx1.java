package ExceptionPractice;

class Test2
{
	protected void finalize() 
	{
		System.out.println("finalize method called");
	}
}



public class FinalizeEx1 {

	public static void main(String[] args) {
		
		
		Test2 obj=new Test2();
		obj=null;
		System.out.println("Object ready for garbage collection");
		System.gc();
		
		
		
		
		

	}

}
