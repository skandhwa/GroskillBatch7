package ExceptionPractice;

import java.io.File;
import java.io.FileNotFoundException;

class A
{
public static void getFileAccess(int empID) throws FileNotFoundException
{
	if(empID==12345)
	{
	File f=new File("‪D:\\Assignment OOPS.txt");
  //   boolean flag=	f.canRead();
//System.out.println("Can u read this file  "+flag);
	System.out.println("You have access to file");
	}
	else
	{
		throw new FileNotFoundException("U dont have access to file");
	}
	
}
}

public class ThrowingCheckedException {

	public static void main(String[] args) throws FileNotFoundException {
		
		A.getFileAccess(12345);
		
		
		

	}

}
