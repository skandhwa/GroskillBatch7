package ExceptionPractice;

import java.io.File;

public class Throwsex2 {

	public static void main(String[] args) {
		
		
		
		
		
		

	}

}
