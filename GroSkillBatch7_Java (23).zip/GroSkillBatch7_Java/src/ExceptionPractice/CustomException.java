package ExceptionPractice;

class InvalidAgeException extends Exception
{
	public InvalidAgeException(String msg)
	{
		System.out.println("This class is for custom exception "+msg);
	}
}

class Test
{
	public static void checkAge(int a) throws InvalidAgeException
	{
		if(a<18)
		{
			throw new InvalidAgeException("Age not valid");
		}
		else
		{
			System.out.println("Valid age");
		}
	}
}






public class CustomException {

	public static void main(String[] args) throws InvalidAgeException {
		
		
		Test.checkAge(14);
		
		
		

	}

}
