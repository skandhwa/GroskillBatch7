package ExceptionPractice;

public class FinallyBlockExample {

	public static void main(String[] args) {
		
		try
		{
		int x=20/4;
		System.out.println(x);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Caught with  "+e.getMessage());
		}
		
		
		finally
		{
			String str="India";
			int x=str.length();
			System.out.println("Length of String is  "+x);
		}
		
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		
		
		
		

	}

}
