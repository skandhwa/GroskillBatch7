package ExceptionPractice;

public class ThrowsExample1 {

	public static void main(String[] args) throws InterruptedException  {
		
		Thread.sleep(3000);
		int x=20,y=30;
		int z=x+y;
		
		System.out.println(z);
		

	}

}
