
import { test, expect } from '@playwright/test';

test('Validate Single Frame', async ({ page }) => 
    {
        
  await page.goto('https://demo.automationtesting.in/Frames.html');
 const frameloc= await page.frameLocator("#singleframe");
 await page.waitForTimeout(3000);

 await frameloc.locator("input[type='text']").fill("Saurabh");
  await page.waitForTimeout(3000);


});

test('Handling Multiple Frames', async ({ page }) => 
    {
        
  await page.goto('https://demo.automationtesting.in/Frames.html');
  await page.waitForTimeout(3000);
  await page.click('a[href="#Multiple"]');
  await page.waitForTimeout(3000);
  const parentFrame=await page.frameLocator('iframe[src="MultipleFrames.html"]');
  await page.waitForTimeout(3000);
  const childFrame=await parentFrame.frameLocator('iframe[src="SingleFrame.html"]');
  await page.waitForTimeout(3000);
  await childFrame.locator('input[type="text"]').fill("Saurabh and inside nested frame");
await page.waitForTimeout(3000);
  await page.locator('a[href="#Single"]').click();
await page.waitForTimeout(3000);



});