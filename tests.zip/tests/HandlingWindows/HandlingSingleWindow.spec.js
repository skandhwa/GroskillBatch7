
import { test, expect } from '@playwright/test';

test('Validate Single Window', async ({ browser }) => 
    {
      
    const context=    await browser.newContext();
    const page= await context.newPage();
 await page.goto('https://demo.automationtesting.in/Windows.html');
const docLink=await page.locator("(//button[@class='btn btn-info'])[1]");

const [newPage]=await Promise.all([context.waitForEvent('page'),docLink.click()]);

//await newPage.waitforLoadState();

console.log(await newPage.title());

});


test.only('Validate New Separate Window', async ({ browser }) => {

    const context = await browser.newContext();
    const page = await context.newPage();

    await page.goto('https://demo.automationtesting.in/Windows.html');

    // Click Open New Separate Windows
  
    await page.locator("a[href='#Seperate']").click();
    // Click the button which opens a new window
    const openButton = page.locator("(//button[@class='btn btn-info'])[2]");

    const [newPage] = await Promise.all([
        context.waitForEvent('page'),
        openButton.click()
    ]);

    await newPage.waitForLoadState();

    console.log("Title:", await newPage.title());
    console.log("URL:", newPage.url());

});


 
