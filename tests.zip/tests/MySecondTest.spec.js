import { test, expect } from '@playwright/test';

test.describe('Login Tests', () => {

    test('Valid login', async ({ page }) => {
        await page.goto('https://google.com');
        // test steps
    });

    test('Invalid login', async ({ page }) => {
        await page.goto('https://amazon.com');
        // test steps
    });

    test('Forgot password', async ({ page }) => {
        await page.goto('https://flipkart.com');
        // test steps
    });

});