
import { test, expect } from '@playwright/test';

test('Handling Keyboard Operations', async ({ page }) => 
    {
        
           await page.goto("https://demo.automationtesting.in/Register.html");
           await page.keyboard.press('ArrowDown');
           await page.keyboard.press('ArrowDown');
             await page.keyboard.press('Tab');
           await page.keyboard.press('ArrowDown');
           await page.keyboard.press('ArrowDown');
            await page.keyboard.press('ArrowUp');
             await page.keyboard.press('ArrowUp');
              await page.keyboard.press('ArrowUp'); 
              await page.keyboard.press('ArrowUp');

              await page.getByPlaceholder("First Name").click();
              await page.keyboard.type("Saurabh")

               await page.getByPlaceholder("First Name").click();
               await page.keyboard.press('Control+A')
               await page.keyboard.press('Control+C')
              await page.getByPlaceholder("Last Name").click();
              await page.keyboard.press('Control+V')
              

               await page.keyboard.down('Shift')
               await page.keyboard.press('ArrowDown')
               await page.keyboard.up('Shift')










  



});


test.only('Handling Keyboard Operations2', async ({ page }) => 
    {
        
           await page.goto("https://www.google.com/");
           await page.locator('textarea[jsname="yZiJbe"]').fill("Playwright documents")
           await page.locator('textarea[jsname="yZiJbe"]').press('Enter')
           await page.waitForTimeout(3000);
           

         










  



});