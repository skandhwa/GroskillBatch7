import { test } from '@playwright/test';

test('Right Click and Double Click', async ({ page }) => {

    await page.goto(
        'https://www.tutorialspoint.com/selenium/practice/buttons.php'
    );

    // Right Click
    await page.getByRole('button', {name: 'Right Click Me'
    }).

    click({ button: 'right' });

    await page.waitForTimeout(5000);

    // Double Click
    await page.getByRole('button', {
        name: 'Double Click Me'
    }).dblclick();

});