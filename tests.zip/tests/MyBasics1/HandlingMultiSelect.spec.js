
import { test, expect } from '@playwright/test';

test('handling Multi select', async ({ page }) => 
    {
       
  await page.goto('https://www.qapractice.com/practice-different-ui-elements?utm_source=chatgpt.com');
  let multi=await page.locator("#multiDropdown");
  
 await multi.selectOption({index:3})
await multi.selectOption('OptionB')
 //await  multi.selectOption({label:'OptionD'})    



 


});