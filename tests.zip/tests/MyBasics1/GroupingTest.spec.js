
import { test, expect } from '@playwright/test';

test.describe('Validate Pages',()=>
{


    test.describe.configure({mode:'serial'})

test('has title @sanity', async ({ page }) => 
    {
       
  await page.goto('https://demo.guru99.com/V4/index.php');
  //  await expect(page).toHaveTitle("Google");


});

test('Validate Amazon @smoke @sanity', async ({ page }) => 
    {
  await page.goto('https://amazon.com');


});

test('Validate Flipkart @sanity', async ({ page }) => 
    {
  await page.goto('https://flipkart.com');


})

});