
import { test, expect } from '@playwright/test';

test('Validate WebElements', async ({ page }) => 
    {

       await page.goto("https://demo.automationtesting.in/Register.html") 
    //    await page.pause();
    //    await page.waitForTimeout(3000);
       await expect(page).toHaveTitle('Register')
      await expect(page).toHaveURL("https://demo.automationtesting.in/Register.html");
     // await page.waitForTimeout(3000);
    //   await page.waitForEvent('domcontentloaded')

let Fnameloc=await page.getByPlaceholder('First Name')

await expect(Fnameloc).toBeEnabled();
await expect(Fnameloc).toBeVisible();

await Fnameloc.fill('Saurabh');

await page.getByRole('textbox', { name: 'Last Name' }).fill('K');
//await page.getByLabel('Male').check();
await page.locator("input[value='Male']").check();
await page.locator("#checkbox1").check();


const pageTitleval=await page.locator("//h2").textContent()
console.log(pageTitleval)

let dropDownVal=await page.locator("#Skills").allTextContents()
console.log(dropDownVal)

const dropDownoption=await page.locator("#Skills");

//await dropDownoption.selectOption({index:3})
//await dropDownoption.selectOption('Android')
 await  dropDownoption.selectOption({label:'Analytics'})     
await page.waitForTimeout(3000);  

});