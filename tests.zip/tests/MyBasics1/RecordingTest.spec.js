import { test, expect } from '@playwright/test';

test('test @demo', async ({ page }) => {
  await page.goto('https://demo.automationtesting.in/Register.html');
  await page.getByRole('textbox', { name: 'First Name' }).click();
  await page.getByRole('textbox', { name: 'First Name' }).fill('Saurabh');
  await page.getByRole('textbox', { name: 'Last Name' }).click();
  await page.getByRole('textbox', { name: 'Last Name' }).fill('Kandhway');
  await page.locator('textarea').click();
  await page.locator('textarea').fill('Delhi');
  await page.locator('input[type="email"]').click();
  await page.locator('input[type="email"]').fill('sak12@gmail.com');

  await expect(page.locator('input[type="tel"]')).toBeVisible();
  await expect(page.locator('#msdd')).toBeVisible();
  await expect(page.locator('h2')).toContainText('Register');
  await page.getByText('Skills', { exact: true }).click();
});