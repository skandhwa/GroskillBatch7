
import { test, expect } from '@playwright/test';

test('has title', async ({ page }) => 
    {
        test.slow(true);
  await page.goto('https://demo.guru99.com/V4/index.php');
  //  await expect(page).toHaveTitle("Google");


});

test('Validate Amazon', async ({ page }) => 
    {
  await page.goto('https://amazon.com');


});

test('Validate Flipkart', async ({ page }) => 
    {
  await page.goto('https://flipkart.com');


});