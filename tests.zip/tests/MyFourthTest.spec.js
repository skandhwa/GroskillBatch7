import { test, expect } from '@playwright/test';

test('My third Playwright Test', async ({ page })=>
{

   await page.goto("https://www.flipkart.com/");
    let title=await page.title();
    console.log(title);
    
})


test('My fourth Playwright Test', async ({ page })=>
{

   await page.goto("https://www.amazon.com/");
    let title=await page.title();
    console.log(title);
    
})

test('My fifth Playwright Test', async ({ page })=>
{

   await page.goto("https://www.instagram.com/");
    let title=await page.title();
    console.log(title);
    
})

test('My sixth Playwright Test', async ({ page })=>
{

   await page.goto("https://www.linkedin.com/");
    let title=await page.title();
    console.log(title);
    
})


test('My seventh Playwright Test', async ({ page })=>
{

   await page.goto("https://www.facebook.com/");
    let title=await page.title();
    console.log(title);
    
})



