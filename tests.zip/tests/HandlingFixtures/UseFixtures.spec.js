
import { test } from './HandlingLoginfixtures'

test('Validate Login', async ({ logInPage }) => 
    {
       
   await logInPage.locator("a[href='addcustomerpage.php']").click();

});