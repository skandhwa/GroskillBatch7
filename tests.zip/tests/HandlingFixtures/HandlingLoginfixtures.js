import { test as base, expect } from '@playwright/test';

export const test= base.extend(

    {

        logInPage: async({page},use) =>
        {

            await page.goto("https://demo.guru99.com/V4/index.php")
            await page.locator('input[name="uid"]').fill("mngr666553");
            await page.locator('input[name="password"]').fill("dUgUrAg");
                  await page.locator('input[name="btnLogin"]').click();

                  await use(page);

                  console.log("Test is being completed")

        }

    }



);