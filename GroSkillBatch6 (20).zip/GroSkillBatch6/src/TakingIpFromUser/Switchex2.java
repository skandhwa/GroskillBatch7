package TakingIpFromUser;

import java.util.Scanner;

public class Switchex2 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		int input=sc.nextInt();
		switch(input)
		{
		case 1:
			System.out.println("You got Outstanding");
			break;
		case 2:
			System.out.println("You got Exceed Expectations");
			break;
		case 3:
			System.out.println("You got Met Expectations");
			break;
		case 4:
			System.out.println("partially meeting Expectations");
			break;
		case 5:
			System.out.println("PIP needs to implemented");
			break;
		default:
			System.out.println("You entered invalid choice");
			
		}
		
		

	}

}
