package ArrayExamples;

public class ArrayDeclarationEx {

	public static void main(String[] args) {
		
		int []a= {23,45,67,89,99};
		
		for(int i=0;i<=a.length-1;i++)//i=0,0<5//i=1,1<5
		{
			
			System.out.println(a[i]);//a[0]//a[1]
		}
		
		System.out.println("########################################################");
		
		for(int x:a)
		{
			if(x==a[3])
			{
				break;
			}
			System.out.println(x);
		}
		
		
		
		
		
		
		
		
		
		
		

	}

}
