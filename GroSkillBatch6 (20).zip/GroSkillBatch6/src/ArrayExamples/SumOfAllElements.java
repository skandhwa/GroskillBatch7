package ArrayExamples;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int []a= {12,56,77,88,34};
		
		int sum=0;
		
		for(int i=0;i<a.length;i++)//i=0,0<5//1<5//2<5
		{
			sum=sum+a[i];//sum=0+a[0]=12//sum=12+56=68//sum=68+77=145
		}
		
		System.out.println(sum);
		

	}

}
