package ArrayExamples;

public class JaggedArrayEx {

	public static void main(String[] args) {
		
		int[][] a = {
			    {1, 5},
			    {2, 4, 6},
			    {7}
			};

			for (int i = 0; i < a.length; i++) {
			    
			    for (int j = 0; j < a[i].length; j++) {
			        System.out.print(a[i][j] + " ");
			    }

			    System.out.println();
			}
		

	}

}
