package ArrayExamples;

import java.util.Arrays;
import java.util.Scanner;

public class TakeInputFromUserArray {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your array size");
		int n=sc.nextInt();
		System.out.println("Enter the "+ n + "elemnts of the array");
		int []a=new int[n];
		
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		
		
		System.out.println(Arrays.toString(a));
		
		System.out.println();
		Arrays.sort(a);
		
		for(int x :a)
		{
			System.out.println(x);
		}
		System.out.println();
		
		System.out.println("The Sorted Array is  \n");
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)//j=5
			{
				if(a[i]<a[j])///
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		
		for(int x:a)
		{
			System.out.print(x+" ");
		}
		
		

	}

}
