package ArrayExamples;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		int []a= {12,-145,67,88};
		int []b= {12,45,167,88};
		
//	boolean flag=	Arrays.equals(a,b);
//	
//	System.out.println(flag);
//	
//	Arrays.sort(b);
//	
//	for(int x:b)
//	{
//		System.out.println(x);
//	}
	
	int z=	Arrays.compare(a,b);
	
	System.out.println("Output for Array comparision is  "+z);
	
	
	
	
	

	
	
		

	}

}
