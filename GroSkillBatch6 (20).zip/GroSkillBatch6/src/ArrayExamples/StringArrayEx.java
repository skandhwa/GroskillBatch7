package ArrayExamples;

public class StringArrayEx {

	public static void main(String[] args) {
		
		String []a= {"hi","hello","how r u"};
		
		int x=a.length;
		
		System.out.println(x);
		
		for(String y:a)
		{
			System.out.println(y);
		}
		
		
		

	}

}
