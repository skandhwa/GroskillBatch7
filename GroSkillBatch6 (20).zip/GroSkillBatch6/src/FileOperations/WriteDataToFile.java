package FileOperations;

import java.io.FileWriter;
import java.io.IOException;

public class WriteDataToFile {

	public static void main(String[] args) throws IOException {
		
		FileWriter fw=new FileWriter("D:/TestDataFolder17thOct/‪MyTest.txt");
		fw.write("Java is OOPs \n");
		System.out.println();
		System.out.println("Content added successfully");
		fw.append("Java is powerful \n");
		System.out.println();
		System.out.println("COntent added ");
		
		fw.close();
		
		///  D:\\TestDataFolder17thOct\\MyTest.txt
		

	}

}
