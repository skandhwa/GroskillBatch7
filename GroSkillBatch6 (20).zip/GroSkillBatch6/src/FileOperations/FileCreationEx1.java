package FileOperations;

import java.io.File;
import java.io.IOException;

public class FileCreationEx1 {

	public static void main(String[] args) throws IOException {
		
		File obj=new File("D:\\TestDataFolder17thOct\\MyTest4.txt");
		
	boolean flag=	obj.createNewFile();
	
	System.out.println("Is the file created  "+flag);
	
	System.out.println(obj.getName()); 
	
	System.out.println  (obj.getAbsolutePath());
	
	 boolean flag1=      obj.canRead();
	 
	 System.out.println("Is the file readable  "+flag1);
	 
boolean flag2=      obj.canWrite();
	 
	 System.out.println("Is the file writable  "+flag2);
	 
	 
	long x=  obj.length();
	
	System.out.println("Length of file is  "+x);
	
  boolean flag3=	obj.delete();
  
  System.out.println("Is the file deleted  "+flag3);
	
	
	
	
	
	
		

	}

}
