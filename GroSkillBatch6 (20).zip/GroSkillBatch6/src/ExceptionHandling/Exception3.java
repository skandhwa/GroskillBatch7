package ExceptionHandling;

public class Exception3 {

	public static void main(String[] args) {
		
		try
		{
		int []arr= {34,67,89,12,56};
		
		System.out.println(arr[6]);
		
		}
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Caught with  "+e.getMessage());
		}
		
		
		int a=20,b=30,c=40;
		int res=a+b+c;
		System.out.println(res);

		

	}

}
