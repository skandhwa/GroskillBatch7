package ExceptionHandling;

class Shape
{
double l=20;
double b=5;
int a =5;
void square ()
{
System.out.println("Area="+a*a);
}
void rectangle()
{

System.out.println("Area="+l*b);

}


void circle()
{
System.out.println("Area="+3.14*a*a);
}

}



public class Problem24 {

public static void main(String[] args) {
// TODO Auto-generated method stub

Shape obj = new Shape();
obj.square();
obj.rectangle();
obj.circle();

}

}