package ExceptionHandling;

public class Exceptionex2 {

	public static void main(String[] args) {
		try
		{
		
		String str=null;
		int x=str.length();
		System.out.println(x);
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		int a=20,b=30,c=40;
		int res=a+b+c;
		System.out.println(res);
		

	}

}
