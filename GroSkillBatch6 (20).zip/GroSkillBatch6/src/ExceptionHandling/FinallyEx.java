package ExceptionHandling;

public class FinallyEx {

	public static void main(String[] args) {
		
		try
		{
		int x=9/3;
		System.out.println(x);
		}
//		catch(Exception e)
//		{
//			System.out.println("Caught with  "+e);
//		}
		
		
		
		

		
		finally
		{
		
		int a=10,b=20;
		int c=a+b;
		System.out.println(c);
		
		
		String str="Saurabh";
		System.out.println(str.length());
		
		}
		
		
		
		System.out.println("Hello");
		
		
		

	}

}
