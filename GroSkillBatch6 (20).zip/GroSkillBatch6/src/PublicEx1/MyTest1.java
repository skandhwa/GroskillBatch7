package PublicEx1;

public class MyTest1 {
	
	public void display()
	{
		System.out.println("Hello");
	
	}
	

	public static void main(String[] args) {
		
		MyTest1 obj=new MyTest1();
		obj.display();
		

	}

}
