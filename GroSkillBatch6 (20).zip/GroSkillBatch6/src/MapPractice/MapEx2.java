package MapPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx2 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(34, "Sam");
		mp.put(65, "Tom");
		mp.put(14, "Kim");
		mp.put(78, "John");
		
		int x=mp.size();
		System.out.println("Size of map is  "+x);
		
	boolean flag=	mp.containsKey(65);
	
	System.out.println("Does the map contains 65 "+flag);
	
  System.out.println(mp.get(14));	
  
  mp.replace(14, "Tony");
  
  System.out.println(mp);
		
		
		Map<Integer,String> mp2=new LinkedHashMap<Integer,String>();
		mp2.put(34, "Sam");
		mp2.put(65, "Tom");
		mp2.put(64, "Kane");
		mp2.put(99, "Dan");
		
		
		
		

	}

}
