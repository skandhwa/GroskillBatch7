package ProtectedEx1;

public class MyTest1 {
	
	protected int x=10;
	protected   void display()
	{
		System.out.println("Hello");
	}
	
	
	
	
	

	public static void main(String[] args) {
		
		MyTest1 oj=new MyTest1();
		System.out.println(oj.x);
		oj.display();
		
		

	}

}
