package DefaultPractice2;

import DefaultPractice1.MyDefaultEx1;

public class MyDefaultEx3 {

	public static void main(String[] args) {
		
		
		MyDefaultEx1 obj=new MyDefaultEx1();
		obj.display();
	System.out.println(obj.x);	

	}

}
