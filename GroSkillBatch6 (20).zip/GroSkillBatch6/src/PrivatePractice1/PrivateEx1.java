package PrivatePractice1;


public class PrivateEx1 
{
	
	private static int x=10;
	private static int y=20;
	
	private void display()
	{
		System.out.println("Hello");
	}
	
	private static int add(int x,int y)
	{
		return x+y;
	}
	
	private static int add(int x,int y,int z)
	{
		return x+y+z;
	}
	

	public static void main(String[] args) 
	{
		
		int z=x+y;
		System.out.println(z);
		PrivateEx1 obj=new PrivateEx1();
		obj.display();
		
	System.out.println(add(12,34));	
	System.out.println(add(12,34,67));	
		

	}

}
