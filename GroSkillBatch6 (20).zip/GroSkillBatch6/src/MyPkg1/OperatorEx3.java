package MyPkg1;

public class OperatorEx3 {

	public static void main(String[] args) {
		
		
		int x=3/10;
		System.out.println(x);
	}

}
