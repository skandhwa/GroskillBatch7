package InterfacePractice;

interface I11
{
	 int x=20;
	
}



public class InterfaceEx7 {

	public static void main(String[] args) {
		

	}

}
