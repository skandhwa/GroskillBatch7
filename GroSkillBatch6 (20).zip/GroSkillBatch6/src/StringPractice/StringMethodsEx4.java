package StringPractice;

public class StringMethodsEx4 {

	public static void main(String[] args) {
		
		String str="Republic";
		
	char ch=	str.charAt(1);
	
	System.out.println(ch);
		
		

	}

}
