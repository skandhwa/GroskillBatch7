package StringPractice;

public class StringReverseWordByWord {

	public static void main(String[] args) {
		
		String str="Java is easy";
		
		String []s=str.split(" ");
		
		for(String x:s)
		{
			String rev="";
			
			for(int i=x.length()-1;i>=0;i--)
			{
				rev=rev+x.charAt(i);
			}
			
			
			System.out.print(rev+" ");
			
		}
		
		
		
		
		
		

	}

}
