package StringPractice;

public class StringEx1 {

	public static void main(String[] args) {
		
		String str="India";  /// Through String literal
		
		String str1="India";
		
		String str3=new String ("Nepal");
		
		String str4=new String ("Nepal");
		
		System.out.println(str==str1);
		
		System.out.println(str3==str4);
		
		String str5= new String("India").intern();
		
		System.out.println(str==str5);
		

	}

}
