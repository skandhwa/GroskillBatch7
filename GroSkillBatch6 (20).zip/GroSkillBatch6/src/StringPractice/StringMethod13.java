package StringPractice;

public class StringMethod13 {

	public static void main(String[] args) {
		
		String str="Playwright";
		String str1="Playwright Selenium";
		
	int x=	str.compareTo(str1);
	
	System.out.println(x);
		
	}

}
