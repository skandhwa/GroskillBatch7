package StringPractice;

public class StringBufferEx1 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Harry");
		
		sb.append("Dsouza");
		
		System.out.println(sb);
		
		
		

	}

}
