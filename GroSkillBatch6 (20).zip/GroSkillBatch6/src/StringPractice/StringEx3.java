package StringPractice;

public class StringEx3 {

	public static void main(String[] args) {
		
		String str="       harry   ";
		
	str=	str.trim();
		
		System.out.println(str);
		

	}

}
