package DefaultPractice1;

public class MyDefaultEx2 {

	public static void main(String[] args) {
		
		
		MyDefaultEx1 obj=new MyDefaultEx1();
		obj.display();
	System.out.println(obj.x);	

	}

}
