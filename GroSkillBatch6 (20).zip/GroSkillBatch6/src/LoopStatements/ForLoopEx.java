package LoopStatements;

public class ForLoopEx {

	public static void main(String[] args) {
		
		for(int i=0;i<=4;i++)//i=0,0<=4//1<=4//2<=4
		{
			System.out.println(i);///0//1//2//3//4
			
		}
		
		
		
		

	}

}
