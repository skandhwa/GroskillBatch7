package LoopStatements;

public class PalindromeNumberEx {

	public static void main(String[] args) {
		
		int num=121;
		
		int act=num;
		
		int rev=0;
		
		while(num!=0)//
		{
			int  d=num%10;//d=321%10=1 //d=32%10=2 ///d=3%10=3
			 
			rev= rev*10 + d;//rev=0*10+1=1///rev=1*10+2=12 // rev=12*10+3=123
			
			num=num/10;//num=321/10=32 /// num= 32/10=3 //num=3/10=0
		}
		
		System.out.println(rev);
		
		if(act==rev)
		{
			System.out.println("The number is plaindrome");
		}
		else
		{
			System.out.println("The number is not a palindrome");
		}
		
		

	}

}
