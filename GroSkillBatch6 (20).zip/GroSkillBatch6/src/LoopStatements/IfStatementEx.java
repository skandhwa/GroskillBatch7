package LoopStatements;

public class IfStatementEx {

	public static void main(String[] args) {
	
		int x=5;
		
		if(x>10)
		{
			System.out.println("Hello");
		}
		
		

	}

}
