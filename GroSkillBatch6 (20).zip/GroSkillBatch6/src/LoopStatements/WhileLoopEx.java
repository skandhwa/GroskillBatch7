package LoopStatements;



public class WhileLoopEx {

	public static void main(String[] args) {
		
		int i=1;//i=0
		while(i<5)//0<5//1<5//2<5//3<5//4<5
		{
			System.out.println(i);//0//1//2//3//4
			i++;//0++//1++//2++//3++
		}
		
		
		

	}

}
