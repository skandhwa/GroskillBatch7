package LoopStatements;

public class doWhileEx {

	public static void main(String[] args) {
		
		int i=1;
		
		do
		{
			System.out.println(i);//0//1//2//3
			i++;//0++//1++//2++//3++
		}
		while(i<4);//1<4//2<4 //3<4//4<4
		

	}

}
