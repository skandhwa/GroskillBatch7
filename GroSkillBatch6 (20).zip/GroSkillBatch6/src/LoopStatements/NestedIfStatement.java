package LoopStatements;

public class NestedIfStatement {

	public static void main(String[] args) {
		
		int age=83;
		
		if(age>18 && age<80)
		{
			System.out.println("You are elligible to vote");
			
			if(age>80)
			{
				System.out.println("Your vote will be taken from home");
				
				
				
			}
			
		}
		
		

	}

}
