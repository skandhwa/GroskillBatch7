package LoopStatements;

public class SumOfAllDigitsOfNumber {

	public static void main(String[] args) {
		
		int num=868768;
		
		int sum=0;
		
		while(num!=0)
		{
			int d= num%10; //// d=321%10=1  // d=32%10=2  //d=3%10=3
			sum= sum+d; ///sum=0+1=1  //sum=1+2=3//sum=3+3=6
			num=num/10; /// num=32  //num=32/10=3 //num=3/10=0
		}
		
		System.out.println("Sum of digits is  "+sum);
		
		
		

	}

}
