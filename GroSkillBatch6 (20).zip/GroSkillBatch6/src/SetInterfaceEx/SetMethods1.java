package SetInterfaceEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods1 {

	public static void main(String[] args) {
		
		
		Set<String> s1=new  LinkedHashSet<String>();
		s1.add("melon");
		s1.add("kiwi");
		s1.add("orange");
		s1.add("mango");
		
		Set<String> s2=new  LinkedHashSet<String>();
		s2.add("banana");
		s2.add("pineapple");
		s2.add("orange");
		s2.add("mango");
		
//		s1.addAll(s2);
//		
//		for(String x:s1)
//		{
//			System.out.println(x);
//		}
		
//		
//	boolean flag=	s1.containsAll(s2);
//	System.out.println(flag);
		
		
//		s1.retainAll(s2);
//		
//		System.out.println(s1);
//		
		
		s1.removeAll(s2);
		System.out.println(s1);
		
		

	}

}
