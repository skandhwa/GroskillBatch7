package SetInterfaceEx;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		Set<String> s1=new LinkedHashSet<String>();
		
		s1.add("harry");
		s1.add("adam");
		s1.add("banton");
		s1.add("clark");
		
		List<String> li=new LinkedList<String>();
		
		
		
		
		for(String x:s1)
		{
			li.add(x);
		}
		
		Collections.sort(li);
		
		System.out.println(li);

	}

}
