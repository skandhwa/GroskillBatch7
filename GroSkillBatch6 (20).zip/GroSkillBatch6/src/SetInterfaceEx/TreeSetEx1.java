package SetInterfaceEx;

import java.util.TreeSet;

public class TreeSetEx1 {

	public static void main(String[] args) {
		
		TreeSet<String> s1=new TreeSet<String>();
		s1.add("mango");
		s1.add("banana");
		s1.add("orange");
		s1.add("apple");
		
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("Storing elements in descending order");
		
	System.out.println(s1.descendingSet());	
	
	
	
		
		
		
		
		
		
		
		

	}

}
