package SetInterfaceEx;

import java.util.TreeSet;

public class TreeSetEx2 {

	public static void main(String[] args) {
		
		TreeSet<Integer> s1=new TreeSet<Integer>();
		s1.add(34);
		s1.add(55);
		s1.add(14);
		s1.add(65);
		//s1.add(null);
		
		
	System.out.println(s1.ceiling(30));	
	
	System.out.println(s1.floor(10));
	
	
		
		
		

	}

}
