package SetInterfaceEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class SetMethods3 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		s1.add(56);
		s1.add(12);
		s1.add(68);
		s1.add(89);
		
	boolean flag=	s1.contains(56);
	System.out.println(flag);
	
	s1.remove(1);
	
Object[]arr=	s1.toArray();
	System.out.println(s1);
		
		

	}

}
