package ListImplementation;

import java.util.Arrays;
import java.util.List;

public class ArrayToArrayList {

	public static void main(String[] args) {
		
		int []a= {2,5,6,7,8};
		
		List<int[]> li=Arrays.asList(a);
		

	}

}
