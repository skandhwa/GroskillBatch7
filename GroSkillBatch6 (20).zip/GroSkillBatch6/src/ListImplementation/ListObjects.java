package ListImplementation;

import java.util.ArrayList;
import java.util.List;

public class ListObjects {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(23);
		li.add("Harry");
		li.add(true);
		li.add(89765.76);
		
		for(Object x:li)
		{
			System.out.println(x);
		}

	}

}
