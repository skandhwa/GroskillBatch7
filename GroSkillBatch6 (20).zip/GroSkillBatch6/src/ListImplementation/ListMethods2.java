package ListImplementation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListMethods2 {

	public static void main(String[] args) {
		
		List<String>li=new ArrayList<String>();
		li.add("mango");
		li.add("guava");
		li.add("apple");
		li.add("papaya");
		li.add("melon");
		
		List<String>li2=new ArrayList<String>();
		li2.add("orange");
		li2.add("lemon");
		li2.add("kiwi");
		li2.add("papaya");	
		li2.add("melon");
		
		Collections.sort(li);
		Collections.reverse(li2);
	
		
		
		
//		li.addAll(li2);
//		
//		System.out.println(li);
		
		
//	boolean flag2=	li.containsAll(li2);
//	
//	System.out.println(flag2);
		
//		li.removeAll(li2);
//		
//		System.out.println(li);
		
//		li.retainAll(li2);
//		
//		System.out.println(li);
		
		li.clear();
		
		System.out.println(li);
		
		
		
		

	}

}
