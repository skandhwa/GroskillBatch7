package ListImplementation;

import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		
		
		LinkedList<String> li=new LinkedList<String>();
		
		li.add("apple");
		li.add("orange");
		li.add("melon");
		li.add("kiwi");
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		
		
		

	}

}
