let s1 = Symbol("Geeks")
let s2 = Symbol("Geeks")
console.log(s1 == s2)