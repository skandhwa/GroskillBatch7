function test(name,callback)
{
    console.log("Hello "+name)
}

function display()
{
    console.log("I am display")
}

test("Harry",display)
