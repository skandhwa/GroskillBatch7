class Emp {

    static comName = "TCS";

    constructor(name, age, salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    display() {
        console.log(
            Emp.comName + " " +
            this.name + " " +
            this.age + " " +
            this.salary
        );
    }
}

let obj = new Emp("Rahul", 45, 90000);
let obj1 = new Emp("Amit", 55, 190000);

obj.display();
obj1.display();