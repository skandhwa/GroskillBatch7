class X1
{
    X1()
    {
        console.log("I am default constructor")
    }

   add(a,b)
   {
    return a+b;
   }

   subtract(c,d)
   {
    return c-d;
   }


}

let obj=new X1();
 console.log(   obj.add(56,67));
 console.log(   obj.subtract(23,12));

