let x=50
 x=88.99

console.log(typeof x)

let y=30/0
console.log(y)

let z=900719925474099545654654n

console.log(typeof z)

let name="Saurabh"
console.log(typeof name)


let username
console.log(username)

let p=null
console.log(p)