// let name="Saurabh"
// let messsage= "How r u"
// console.log(name)
// console.log(messsage)

let name="Saurabh"
let x=`Hello World`
let age='33'

console.log(`My name is ${name} and my age is ${age} `)
