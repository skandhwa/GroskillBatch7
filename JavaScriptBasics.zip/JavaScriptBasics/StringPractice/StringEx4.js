let str="JavaScript"
console.log(str.substring(-3));


console.log(str.slice(-3));