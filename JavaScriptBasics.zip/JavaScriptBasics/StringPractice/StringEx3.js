let str="Hello"

str[0]="p"

console.log(str)