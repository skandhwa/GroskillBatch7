class X3
{
    static add(a,b,c)
    {
        return a+b+c
    }
}

console.log(X3.add(34,56,78));