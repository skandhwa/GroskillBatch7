try
{
    let x=20;
    console.log(x)


}

// catch(error)
// {
//     console.log("error handled")
// }

finally{
    console.log("I will always execute")
}