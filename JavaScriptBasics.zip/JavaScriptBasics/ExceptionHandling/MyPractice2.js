try{

let x=y;

console.log(x)

}

catch(error)
{
    console.log(error.message)
}