let age=15

try{

if(age<18)
{
    throw new Error("Age must be above 18")
}

console.log("User not elligible")

}

catch(error)
{
    console.log(error.message)
}