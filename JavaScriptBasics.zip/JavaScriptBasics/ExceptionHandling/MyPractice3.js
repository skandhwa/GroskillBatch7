try{

let num=100;

num.toUpperCase();


}
catch(error)
{
    console.log(error.message)
}
