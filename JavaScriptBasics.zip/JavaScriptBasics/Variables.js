// //let x=20
// let x="Saurabh"
// console.log(x)

// if(true)
// {
//     let y=30
//     console.log(y)
// }

// console.log(y)


// const y=30
// y="Saurabh"
// if(true)
// {
//     const z=40
//     console.log(z)
// }

// console.log(z)


var x=30;
var x=50
console.log(x)

if(true)
{
    z=50;
    console.log(z)
}

console.log(z)

