// let a1 = [1, 2, 3, 4, 5];
// console.log(a1);

// const num=[];

// let x= new Array(20,40,50);
// console.log(x[0])

const fruits=["Apple","banana","Orange"]

console.log(fruits.length)

console.log(fruits[2])

fruits.push("Kiwi");

console.log(fruits)

fruits.pop()

console.log(fruits)

fruits.unshift("Melon")
console.log(fruits)

fruits.shift()
console.log(fruits)