class Animal
{
    run()
    {
        console.log("Animal runs")
    }
}

class Dog extends Animal
{

 eat()
 {
    console.log("Dog eats")
 }

}


let obj=new Dog();
obj.eat();
obj.run();