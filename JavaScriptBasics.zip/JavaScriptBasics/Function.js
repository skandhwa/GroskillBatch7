function display()
{
    console.log("Hello")
}

display();


function show(name)
{
    console.log("Hello "+name)
}

show("Harry")


function add(a,b)
{
    return a+b
}

const res=add(40,50)
console.log(res)

const add1=(a,b) =>

    {
        return a+b
    }
console.log(add1(50,60))




const sub= (a,b) =>
{
    return a-b
}

console.log(sub(40,20))