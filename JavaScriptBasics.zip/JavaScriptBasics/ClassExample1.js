class Student
{

static display()
{
    console.log("Hey how r u")
}

}

Student.display()