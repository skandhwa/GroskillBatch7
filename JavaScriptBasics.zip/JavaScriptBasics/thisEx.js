const emp=
{

name:"Rahul",
age:45,

display()
{
    console.log(this.name);
    console.log(this.age);
}


}

emp.display();


