class Birds
{
   fly()
   {
    console.log("Birds fly")
   }
}

class crow extends Birds
{
    eat()
    {
        console.log("Birds eat")
    }
   
    fly()
    {
        console.log("Crow flies")
    }  

    display()
    {
       this.fly();
        this.eat();
        super.fly();
    }


}

let obj=new crow();
obj.display();