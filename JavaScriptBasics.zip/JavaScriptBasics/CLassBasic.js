class T1
{
 T1()
 {
    console.log("I am constructor")
 }

    display()
    {
        console.log("How r u")
    }
}

let p=new T1()
p.display()