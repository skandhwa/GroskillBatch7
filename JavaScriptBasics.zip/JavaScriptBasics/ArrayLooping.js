// const fruits=["Apple","banana","Orange"]

// for(let i=0;i<fruits.length;i++)
// {
//    console.log(fruits[i])
// }

// const x=[10,20,30,40]

// const res=x.slice(1,3);

// console.log(res)

// console.log(x)


const x=[10,20,30,40,50,60,70,80,90,120,130]

// let flag=x.includes(40)

// console.log(flag)

const res=x.splice(3,6)

console.log(res)

console.log(x)

