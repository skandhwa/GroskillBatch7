class Person
{
    constructor(name,age,salary)
    {
        this.name=name;
        this.age=age;
        this.salary=salary;

    }

   
display()
{
    console.log(`Name is ${this.name}`)
    console.log(`Age is ${this.age}`)
    console.log(`Salary is ${this.salary}`)

}

}

let obj=new Person("Harry",34,80000);
obj.display();


let obj1=new Person("Tom",36,90000);
obj1.display();



