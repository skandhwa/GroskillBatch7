const now=new Date()
console.log(now)

const date=new Date(2026,11,13)
console.log(date)