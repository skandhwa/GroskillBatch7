class P
{
    
    constructor(name,age)
    {
        this.name=name
        this.age=age
    }
}

class E extends P
{
   constructor(name,age,salary)
   {
   
     super(name,age)
    this.salary=salary
    
   }
  
   
    display()
{
    console.log(`Name is ${this.name}`)
    console.log(`Age is ${this.age}`)
    console.log(`Salary is ${this.salary}`)

}

   }




let obj=new E("Rahul",45,80000);
obj.display();