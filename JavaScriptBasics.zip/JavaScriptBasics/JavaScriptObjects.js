const student =
{
 "name":"John",
 "age":40,
 "role":"manager"



}

console.log(student)

console.log(student.role)



const employee={

    "name":"harry",
    "age":60,
    "address":{
        
        "city":"new delhi",
        "zip":713304

    }


}

console.log(employee.address.city);


const person ={

    "name":"tom",
    display:function()
    {
        console.log("hello how r u")
    }
};

person.display();
console.log(person)

