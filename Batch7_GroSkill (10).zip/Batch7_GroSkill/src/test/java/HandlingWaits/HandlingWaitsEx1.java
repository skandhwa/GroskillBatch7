package HandlingWaits;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingWaitsEx1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
	
		
		////Implicit Wait 
		
		//Thread.sleep(3000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		
		
		///Explicit Wait
		
		WebDriverWait x= new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement ele= x.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@id='Skills']")));
		
		
		//Fluent Wait 
		
		FluentWait y=new FluentWait(driver);
		y.withTimeout(Duration.ofSeconds(10));
		y.pollingEvery(Duration.ofSeconds(2));
		y.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("")));
		y.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("")));
		y.ignoring(NoSuchElementException.class);
		
		
		
		
	

	}

}
