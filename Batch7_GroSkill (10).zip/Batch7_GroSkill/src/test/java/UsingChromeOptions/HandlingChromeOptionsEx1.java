package UsingChromeOptions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingChromeOptionsEx1 {

	public static void main(String[] args) {

	  ChromeOptions opt=new ChromeOptions();
	 // opt.addArguments("--start-maximized");
	//	opt.addArguments("--headless=new");
	  
	//  opt.addArguments("--incognito");
	//  opt.addArguments("--disable-notifications");
	 // opt.addArguments("--window-size=1000,500");
		
       WebDriver driver=new ChromeDriver(opt);
       driver.get("https://demo.automationtesting.in/Register.html");
       
    String title=   driver.getTitle();       
    System.out.println("Title of page is  "+title);   
		

	}

}
