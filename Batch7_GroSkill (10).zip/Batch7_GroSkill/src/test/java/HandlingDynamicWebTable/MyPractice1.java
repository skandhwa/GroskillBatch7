package HandlingDynamicWebTable;

import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MyPractice1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter a name");
		
		String ipname=sc.nextLine();
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("file:///D://WebTable3.html");
		driver.manage().window().maximize();
		String before_xpath="//table/tbody/tr[ ";
	      
	      String after_xpath="]/td[3]";
	      
	   List<WebElement> li=   driver.findElements(By.tagName("tr"));
	   
	  int x= li.size();
	  
	  System.out.println("Total rows are  "+x);
	  
	  for(int i=2;i<=x;i++)
	  {
		 String names= driver.findElement(By.xpath(before_xpath+i+after_xpath)).getText();
		 System.out.println(names);
		 
		 if(names.contains(ipname))
		 {
			 String cbx_beforexpath="//table/tbody/tr[";
			 String cbx_afterxpath="]/td[1]/input";
			 
		WebElement ele=	 driver.findElement(By.xpath(cbx_beforexpath+i+cbx_afterxpath));
		ele.click();	 
		System.out.println();
		 System.out.println("Candidate is selected");
	
		 break;
		
		
		 }
		 
		 else
		 {
			 System.out.println("Inavlid input given ! No student present");
		 }
		 
		 
		 
		 
	  }
	  
	    		 
	 

		}

		 
		 
	  
	
		
		

	

}
