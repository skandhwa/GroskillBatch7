package HandlingDynamicWebTable;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingXpathAxes {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
	      driver.get("D:\\WebTable3.html");
	      
	     driver.findElement(By.xpath("//td[contains(text(),'John')]/parent::tr//input")).click();
	     

	}

}
