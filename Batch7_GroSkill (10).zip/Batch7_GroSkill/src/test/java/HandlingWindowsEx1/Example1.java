package HandlingWindowsEx1;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowID=	driver.getWindowHandle();
	System.out.println("Window ID is "+WindowID);
	
	driver.findElement(By.xpath("//*[text()='    click   ']")).click();
	
	Set<String>WindowIDs=   driver.getWindowHandles();
	
	System.out.println(WindowIDs);
	
		

	}

}
