package HandlingWindowsEx1;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Example2 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
	String WindowID=	driver.getWindowHandle();
	System.out.println("Window ID is "+WindowID);
	
	driver.findElement(By.xpath("//*[text()='    click   ']")).click();
	
	Set<String>WindowIDs=   driver.getWindowHandles();
	
	System.out.println(WindowIDs);
		
	Iterator<String> itr=WindowIDs.iterator();
	while(itr.hasNext())
	{
		String childWindow=itr.next();
		if(!WindowID.equals(childWindow))
		{
			driver.switchTo().window(childWindow);
			String title=driver.getTitle();
			System.out.println("Title is  "+title);
			driver.findElement(By.xpath("//*[text()='Downloads']")).click();
			driver.switchTo().window(WindowID);
		String title2=	driver.getTitle();
		System.out.println(title2);
			
		}
	}
	
	
	

	}

}
