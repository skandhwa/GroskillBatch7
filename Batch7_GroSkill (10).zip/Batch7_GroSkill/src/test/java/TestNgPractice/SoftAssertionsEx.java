package TestNgPractice;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class SoftAssertionsEx {

	@Test
	
	public void sofAssertEx()
	{
		SoftAssert obj=new SoftAssert();
		System.out.println("Hello");
		obj.assertEquals(10,20);
		System.out.println("Welcome to Java");
		
		
	}
	
	
	
}
