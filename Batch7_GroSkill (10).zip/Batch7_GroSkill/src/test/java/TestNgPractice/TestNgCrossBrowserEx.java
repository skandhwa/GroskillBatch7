package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgCrossBrowserEx {
	
	public static WebDriver driver;
	
	@Parameters("browser")
	@BeforeMethod
	public void openBrowser(String browser)
	{
		if(browser.equalsIgnoreCase("Chrome"))
		{
			driver=new ChromeDriver();
			
		}
		
		else if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			
		}
		
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			
		}
	}
	
	@Test
	public void run1()
	{
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		Assert.assertEquals(title,"Google");
		
	}
	
	@Test
	public void run2()
	{
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		String title1=driver.getTitle();
		System.out.println(title1);
		
		
	}
	
	
	@Test
	public void run3()
	{
		driver.get("https://www.myntra.com");
		driver.manage().window().maximize();
		String title2=driver.getTitle();
		System.out.println(title2);
		
		
	}
	
	
	@AfterMethod
	public void closeBrowser()
	{
		driver.quit();
	}
	
	
	
	
	
	
	
	

}
