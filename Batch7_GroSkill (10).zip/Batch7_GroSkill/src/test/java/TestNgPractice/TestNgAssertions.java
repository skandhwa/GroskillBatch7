package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class TestNgAssertions {
	
	@Test
	public void myTest1()
	{
		//WebDriver driver=new ChromeDriver();
//		driver.get("https://www.google.com");
//		driver.manage().window().maximize();
//	String title=	driver.getTitle();
	
//	Assert.assertNotEquals(title,"Google1");
//	
//	System.out.println("My Scenario passed ");
	
	Assert.assertFalse(5!=5);
		
	System.out.println("My Scenario passed ");
	}
	
	
	
	
	

}
