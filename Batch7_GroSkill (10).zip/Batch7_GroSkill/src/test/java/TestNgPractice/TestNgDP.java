package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDP {
	
	@DataProvider(name="dp1")

	public Object [][] dpMethod()
	{

	return new Object [][]

	{
		{"Saurabh","K","Hyderabad","abcd@gmail.com"},
		{"Harry","Dsouza","New York","ftrd@gmail.com"}
     
	};

	}
	
	@Test(dataProvider="dp1")
	public void fillForm(String a,String b,String c,String d) throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		ele.sendKeys(a);
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(b);
		driver.findElement(By.xpath("//textarea[@rows='3']")).sendKeys(c);
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(d);
		Thread.sleep(3000);
		driver.quit();
		
		
		
	}
	
	
	

}
