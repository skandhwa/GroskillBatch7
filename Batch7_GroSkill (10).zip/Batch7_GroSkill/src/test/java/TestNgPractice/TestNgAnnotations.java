package TestNgPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestNgAnnotations {
	
	@AfterTest
	public void test1()
	{
		System.out.println("I am after test");//8
	}
	
	@AfterMethod
	public void test12()
	{
		System.out.println("I am after Method");//6
	}
	
	
	@AfterClass
	public void Btest3()
	{
		System.out.println("I am after class B");//7
	}
	
	@AfterClass
	public void Atest3()
	{
		System.out.println("I am after class A");//7
	}
	
	
	
	
	@BeforeClass
	public void test4()
	{
		System.out.println("I am before class");//3
	}
	
	@BeforeMethod
	public void test5()
	{
		System.out.println("I am before method");//4
	}
	
	@Test(priority=-3)
	public void test6()
	{
		System.out.println("I am Test");//5
	}
	
	@BeforeSuite
	public void test7()
	{
		System.out.println("I am before suite");//1
	}
	
	

	@BeforeTest
	public void test8()
	{
		System.out.println("I am before test");//2
	}
	
	

}
