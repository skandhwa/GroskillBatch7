package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgDependsOnEx {
	
	
	@Test(priority=4)
	public void logintest()
	{
		System.out.println("I am login test method");
		
		
	}
	
	@Test(dependsOnMethods= {"logintest"},priority=3)
	public void SearchProducttest()
	{
		System.out.println("I am Search Product test method");
		int x=9/0;
		System.out.println(x);

	}
	
	@Test(dependsOnMethods= {"logintest","SearchProducttest"},priority=2)
	public void AddToCarttest()
	{
		System.out.println("I am Add to cart test method");
	}
	
	
	@Test(priority=-4,dependsOnMethods= {"logintest","SearchProducttest","AddToCarttest"},alwaysRun=true)
	public void PaymentGatewaytest()
	{
		System.out.println("I am Payment Gateway test method");
	}

}

