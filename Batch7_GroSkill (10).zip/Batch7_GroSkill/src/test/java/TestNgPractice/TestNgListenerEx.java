package TestNgPractice;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestNgListenerEx implements ITestListener {
	
	public static WebDriver driver;

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSuccess(result);
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		System.out.println("My Test case failed");
		System.out.println("Taking screenshot");
		
		TakesScreenshot srcshot=(TakesScreenshot)driver;
		File srcFile=srcshot.getScreenshotAs(OutputType.FILE);
		File desPath=new File("E:\\ScreenShot14thJuly\\"+ Math.random()    +"Test1.jpeg");
		try {
			FileUtils.copyFile(srcFile, desPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		ITestListener.super.onTestSkipped(result);
	}
	
	
	
	

	

}
