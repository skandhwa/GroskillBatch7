package TestNgPractice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgPriority {
	
	@Test(priority=4)
	public void test1()
	{
		System.out.println("I am positive priority");//6
	}
	
	@Test(priority=0)
	public void test2()
	{
		System.out.println("I am zero priority");
		Reporter.log("This scenario passed ");//2
		
		
	}
	
	@Test(priority=1)
	public void Btest()
	{
		System.out.println("I am 1 priority B");
		Reporter.log("This scenario with pr1 passed ");//5
		
	
	}
	
	
	@Test(priority=-3)
	public void test3()
	{
		System.out.println("I am  priority with -3");
		Reporter.log("This scenario with pr-3 passed ");///1
	}
	
	@Test(priority='A')//65
	public void test4()
	{
		System.out.println("I am A priority");
		Reporter.log("This scenario with prA passed ");//7
	}
	
	@Test
	public void test5()
	{
		System.out.println("I am default priortiy");//3
	}
	
	
	
	
	
	@Test(priority=1)
	public void Atest()
	{
		System.out.println("I am 1 priority A");//4
	}
	

}
