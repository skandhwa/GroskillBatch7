package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgEnabled {

	@Test
	public void test1()
	{
		System.out.println("This is Test 1");
	}
	
	
	@Test(enabled=false)
	public void test2()
	{
		System.out.println("This is Test 2");
	}
	
	
	@Test
	public void test3()
	{
		System.out.println("This is Test 3");
	}
	
	
	@Test
	public void test4()
	{
		System.out.println("This is Test 4");
	}
	
	
}
