package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgDrcription {
	
	@Test(description="Validate Login test")
	public void myTest1()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		Reporter.log("This Page is being used for getting google page on screen");
		
		
	}
	

}
