package TestNgPractice;

import org.testng.annotations.Test;

public class MyTest1 {
	
	@Test
	
	public void myTest()
	{
		System.out.println("Hello");
	}
	
	
	
	
	

}
