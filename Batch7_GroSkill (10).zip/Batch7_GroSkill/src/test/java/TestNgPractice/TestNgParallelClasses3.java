package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgParallelClasses3 {
	
	
	@Test
	public void openMeesho()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.meesho.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openFacebook()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		
	}


}
