package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgParallelEx1 {
	
	
	@Test
	public void openGoogle()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		Reporter.log("Hey This test is executed by Saurabh");
		
		
	}
	
	@Test
	public void openFlipkart()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openMyntra()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.myntra.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openAmazon()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openMeesho()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.meesho.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openFacebook()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		
	}

}
