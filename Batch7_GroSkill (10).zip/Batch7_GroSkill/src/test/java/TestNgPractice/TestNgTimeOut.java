package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgTimeOut {
	
	@Test(timeOut=5000)
	public void openFlipkart() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com");
		Thread.sleep(6000);
		driver.manage().window().maximize();
		
		
	}
	
	
	

}
