package HandlingComplexActions;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		
		ChromeOptions opt=new ChromeOptions();
		
		opt.addArguments("--disable-notifications");
		opt.addArguments("--incognito");
		WebDriver driver=new ChromeDriver(opt);
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		
		
		
		///Handling Simple Alerts
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
//		driver.navigate().refresh();
		
		/// Handling Confirmation ALerts
		
//		driver.findElement(By.xpath("//*[text()='Alert with OK & Cancel ']")).click();
//		Thread.sleep(3000);
//		//driver.findElement(By.xpath("//*[text()='Close']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
		
		
		///Handling Prompt Alerts
		
		driver.findElement(By.xpath("//*[text()='Alert with Textbox ']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[contains(text(),' prompt ')]")).click();
		Alert alert=driver.switchTo().alert();
		alert.sendKeys("Saurabh K");
		Thread.sleep(3000);
		alert.accept();
	String Value=	driver.findElement(By.cssSelector("#demo1")).getText();
		System.out.println(Value);
		
		
		
		
		
		
		

	}

}
