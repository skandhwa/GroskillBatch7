package ActionClassPractice;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingClickAndHold {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.selenium.dev/selenium/web/mouse_interaction.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.cssSelector("#clickable"));
		
	Actions act=new Actions(driver);
	
	act.clickAndHold(ele).pause(Duration.ofSeconds(5))
	.release().perform();
	
		

	}

}
