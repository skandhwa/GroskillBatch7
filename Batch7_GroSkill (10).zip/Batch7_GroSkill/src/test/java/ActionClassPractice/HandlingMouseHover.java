package ActionClassPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingMouseHover {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		WebElement ele=driver.findElement(By.xpath("(//*[text()='More'])[1]"));
		
		Actions act=new Actions(driver);
		
		act.moveToElement(ele).build().perform();
		
		driver.findElement(By.xpath("(//*[text()='Advertise on Flipkart'])[1]")).click();
		

	}

}
