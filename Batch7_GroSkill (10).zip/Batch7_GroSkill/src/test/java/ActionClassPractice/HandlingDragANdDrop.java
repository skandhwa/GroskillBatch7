package ActionClassPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDragANdDrop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollBy(0,500)","");
		
		WebElement src1= driver.findElement(By.cssSelector("#angular"));
		WebElement src2= driver.findElement(By.cssSelector("#mongo"));
		WebElement src3= driver.findElement(By.cssSelector("#node"));
		
		WebElement target=driver.findElement(By.cssSelector("#droparea"));
		
		Actions act=new Actions(driver);

		act.dragAndDrop(src1, target).build().perform();
		Thread.sleep(3000);
		act.dragAndDrop(src2, target).build().perform();
		Thread.sleep(3000);
		act.dragAndDrop(src3, target).build().perform();
		
		
	}

}
