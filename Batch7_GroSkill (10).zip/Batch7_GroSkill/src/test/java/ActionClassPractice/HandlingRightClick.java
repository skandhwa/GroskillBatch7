package ActionClassPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingRightClick {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().window().maximize();
		Actions act=new Actions(driver);
	WebElement ele=	driver.findElement(By.xpath("//*[text()='right click me']"));
    act.contextClick(ele).build().perform();
    driver.navigate().refresh();
    WebElement ele2=   driver.findElement(By.xpath("//*[contains(text(),'Double-Click ')]"));
    
    act.doubleClick(ele2).build().perform();
	driver.switchTo().alert().accept();
	}

}
