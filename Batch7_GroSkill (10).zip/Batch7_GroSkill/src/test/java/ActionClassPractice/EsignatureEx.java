package ActionClassPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class EsignatureEx {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://szimek.github.io/signature_pad/?utm_source=chatgpt.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
	WebElement ele=	driver.findElement(By.cssSelector("#canvas-wrapper"));
		Actions act=new Actions(driver);
		
		act.moveToElement(ele).clickAndHold().moveByOffset(100, 0)
		.moveByOffset(20, 0)
		   .moveByOffset(20, 10)
		   .moveByOffset(10, 10)
		   .moveByOffset(-10, 10)
		   .moveByOffset(-20, 10)
		   .moveByOffset(-20, 10)
		   .moveByOffset(10, 10)
		   .moveByOffset(20, 10)
		   .moveByOffset(20, 10)
		   .moveByOffset(10, 10)
		   .moveByOffset(-10, 10)
		   .moveByOffset(-20, 10)
		   .moveByOffset(-20, 10)
		   .release()
		   .perform();
		
		

	}

}
