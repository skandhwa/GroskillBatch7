package UsingJavaScriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDropDown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		WebElement ele=driver.findElement(By.cssSelector("#Skills"));
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		//js.executeScript("arguments[0].value='Android';arguments[0].dispatchEvent(new Event('change'))", ele);
		
		js.executeScript("arguments[0].selectedIndex='6';arguments[0].dispatchEvent(new Event('change'))", ele);

	}

}
