package UsingJavaScriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollToElement {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.cssSelector("#firstpassword"));
	
	JavascriptExecutor js=(JavascriptExecutor)driver;
	//js.executeScript("arguments[0].scrollIntoView(true)",ele);
	
	js.executeScript("window.scrollTo(0,document.body.scrollHeight)","");
	Thread.sleep(3000);
	
	js.executeScript("window.scrollTo(0,0)","");	
	
	Thread.sleep(3000);
	js.executeScript("window.scrollBy(500,0)", "");
	Thread.sleep(3000);
	js.executeScript("window.scrollBy(-500,0)", "");

	}

}
