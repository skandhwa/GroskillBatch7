package UsingJavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetPageTitle {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
	String title=	(String)js.executeScript("return document.title");
	
	  System.out.println(title);
	  
	  
	  String currentURL=	(String)js.executeScript("return document.URL");
		
	  System.out.println(currentURL);
	  
	  
	long height =(long) js.executeScript("return document.body.scrollHeight", "");
	
	System.out.println("Height of page is  "+height);
	
	js.executeScript("alert('Hello Selenium');","");
	
	driver.switchTo().alert().accept();
	
	//js.executeScript("arguments[0].style.background='solid red'", "");
	
	js.executeScript("document.body.style.zoom='70%'", "");
	
	
		

	}

}
