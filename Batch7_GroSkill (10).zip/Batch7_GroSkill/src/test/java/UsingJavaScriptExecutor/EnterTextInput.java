package UsingJavaScriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EnterTextInput {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
	WebElement ele1=	driver.findElement(By.xpath("//input[@placeholder='Last Name']"));
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("arguments[0].value='Saurabh';arguments[1].value='Kandhway'",ele,ele1);
	
	WebElement ele2=driver.findElement(By.cssSelector("#checkbox1"));
	WebElement ele3=driver.findElement(By.cssSelector("#checkbox2"));
	
	js.executeScript("arguments[0].click();arguments[1].click()",ele2,ele3);
	
	WebElement ele4=	driver.findElement(By.cssSelector("[rows='3']"));
	js.executeScript("arguments[0].style.border='10px solid yellow'", ele4);
	
	Thread.sleep(3000);
	
	js.executeScript("history.go(0)","");
	
	

	}

}
