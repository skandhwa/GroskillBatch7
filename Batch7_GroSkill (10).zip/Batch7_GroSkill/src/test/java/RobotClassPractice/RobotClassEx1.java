package RobotClassPractice;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RobotClassEx1 {

	public static void main(String[] args) throws AWTException {

         Robot rb=new Robot();
         
         WebDriver driver=new ChromeDriver();
         driver.get("https://demo.automationtesting.in/Register.html");
         rb.keyPress(KeyEvent.VK_DOWN);
         rb.keyPress(KeyEvent.VK_DOWN);
         rb.keyPress(KeyEvent.VK_DOWN);
         rb.keyPress(KeyEvent.VK_DOWN);
         rb.keyPress(KeyEvent.VK_DOWN);
         
         
         rb.mouseMove(120, 500);
         
		

	}

}
