package MyPracticeTest1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class MyTest1 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.google.com");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(5000);
		driver.navigate().forward();
		Thread.sleep(5000);
		driver.navigate().refresh();
		
//		WebDriver driver1=new FirefoxDriver();
//		driver1.get("https://www.google.com");
//		driver1.manage().window().maximize();
//		
//		WebDriver driver2=new EdgeDriver();
//		driver2.get("https://www.google.com");
//		driver2.manage().window().maximize();
		

	}

}
