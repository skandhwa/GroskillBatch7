package MyPracticeTest1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommandsSelenium {

	public static void main(String[] args) throws Exception {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		String title=driver.getTitle();
		System.out.println("Title of web page is  "+title);
		
		if(title.contains("Online Shopping"))
		{
			System.out.println("Correct page opened");
		}
		else
		{
			throw new Exception("No Page found");
		}
		

	}

}
