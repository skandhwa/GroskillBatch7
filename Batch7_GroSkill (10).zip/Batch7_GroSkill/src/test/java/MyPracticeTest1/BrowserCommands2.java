package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands2 {

	public static void main(String[] args) throws Exception {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.findElement(By.xpath("//*[text()='Gmail']")).click();
		String url=driver.getCurrentUrl();
		System.out.println("Url is  "+url);
		
		if(url.contains("gmail"))
		{
			System.out.println("Correct URL opened");
		}
		else
		{
			throw new Exception("InCorrect Url opened");
		}
		
		
		
		

	}

}
