package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathPractice {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.nseindia.com/market-data/live-equity-market");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
	String str=driver.findElement(By.xpath("//*[text()='HDFCBANK']//parent::td//following-sibling::td[7]//span/span")).getText();	
		System.out.println(str);

	}

}
