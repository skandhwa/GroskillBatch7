package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands4 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_pushbutton_disabled2&utm_source=chatgpt.com");
		driver.manage().window().maximize();
		driver.switchTo().frame("iframeResult");
	   WebElement ele= driver.findElement(By.id("myBtn"));
	   boolean flag=ele.isEnabled();
	   System.out.println("Is the element enabled "+flag);
	   driver.findElement(By.xpath("//button[text()='Try it']")).click();
	   Thread.sleep(3000);
	   
	   WebElement ele1= driver.findElement(By.id("myBtn"));
	   boolean flag1=ele1.isEnabled();
	   System.out.println("Is the element enabled "+flag1);

	}

}
