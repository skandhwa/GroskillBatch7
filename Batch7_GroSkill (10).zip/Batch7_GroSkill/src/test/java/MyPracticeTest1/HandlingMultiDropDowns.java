package MyPracticeTest1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiDropDowns {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.testmuai.com/selenium-playground/select-dropdown-demo/");
		driver.manage().window().maximize();
		WebElement ele=driver.findElement(By.id("multi-select"));
		Select oselect=new Select(ele);
		
	boolean flag=	oselect.isMultiple();
	System.out.println("Is the Language drop down multiselect "+flag);
	oselect.selectByIndex(0);
	oselect.selectByValue("Florida");
	oselect.selectByVisibleText("Texas");
//	Thread.sleep(3000);
//	oselect.deselectAll();

System.out.println("Get First Selected Option");
WebElement ele2=oselect.getFirstSelectedOption();
System.out.println(ele2.getText());

System.out.println("Get All Selected Option");
List<WebElement> li=	oselect.getAllSelectedOptions();
for(int i=0;i<li.size();i++)
{
	System.out.println(li.get(i).getText());
}

Thread.sleep(3000);
oselect.deselectByIndex(0);
oselect.deselectByVisibleText("Texas");






	
		

	}

}
