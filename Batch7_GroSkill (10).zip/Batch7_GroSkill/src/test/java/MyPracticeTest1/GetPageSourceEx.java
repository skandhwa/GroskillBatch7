package MyPracticeTest1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetPageSourceEx {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		
		//driver.manage().window().maximize();
		driver.manage().window().minimize();
		
		
	String pagesource=	driver.getPageSource();
	System.out.println("Page source is  "+pagesource);

	}

}
