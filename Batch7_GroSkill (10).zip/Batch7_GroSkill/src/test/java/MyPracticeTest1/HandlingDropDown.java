package MyPracticeTest1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDown {

	public static void main(String[] args) {

		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.id("Skills"));
	Select oselect=new Select(ele);
	//oselect.selectByIndex(5);
	//oselect.selectByVisibleText("Backup Management");
	//oselect.selectByValue("Client Server");
	
	
	List<WebElement> li=oselect.getOptions();
	
	for(int i=0;i<li.size();i++)
	{
		//System.out.println(li.get(i).getText());
		
		if(li.get(i).getText().equalsIgnoreCase("autocad"))
		{
			oselect.selectByIndex(i);
		}
		
		
	}
	
	System.out.println("#######################################################");
	
	
	
	
		
		

	}

}
