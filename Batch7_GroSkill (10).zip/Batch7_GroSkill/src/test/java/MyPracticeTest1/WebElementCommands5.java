package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.id("checkbox2"));
	if(ele.isDisplayed()==true)
	{
		boolean flag=ele.isSelected();
		System.out.println("Is the element selected "+flag);
		Thread.sleep(4000);
		boolean flag2=ele.isSelected();
		System.out.println("Is the element selected "+flag2);
		
	}
	
		

	}

}
