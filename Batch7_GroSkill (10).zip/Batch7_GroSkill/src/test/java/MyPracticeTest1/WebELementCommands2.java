package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebELementCommands2 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(4000);
	WebElement ele=	driver.findElement(By.xpath("//input[@value='Male']"));
		ele.click();

		driver.findElement(By.xpath("//*[text()=' Submit ']")).submit();
		
	}

}
