package MyPracticeTest1;



import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebELementCommands3 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		
	boolean flag=ele.isDisplayed();
	
	if(flag==true)
	{
		ele.sendKeys("Saurabh");
	}
	
	else
	{
		throw new NoSuchElementException("Please correct your locator");
	}
	

	}

}
