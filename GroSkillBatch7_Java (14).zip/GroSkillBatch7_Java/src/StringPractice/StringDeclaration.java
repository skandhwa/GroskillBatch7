package StringPractice;

public class StringDeclaration {

	public static void main(String[] args) {
		
		String str="Hello";//By Using String literal
		
		String str1=new String("Welcome");
		
		
		

	}

}
