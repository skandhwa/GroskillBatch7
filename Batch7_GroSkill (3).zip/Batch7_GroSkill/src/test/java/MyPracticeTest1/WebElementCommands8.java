package MyPracticeTest1;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands8 {

	public static void main(String[] args) {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='Last Name']"));

	 Dimension size=ele.getSize();
	 
	 System.out.println("Height is  "+size.getHeight());
	 System.out.println("Width is  "+size.getWidth());
	 
	 
	 Point location=ele.getLocation();
	 
	 System.out.println("X coordinate is  "+location.getX());
	 
	 System.out.println("Y coordinate is  "+location.getY());
	 
	
	}

}
