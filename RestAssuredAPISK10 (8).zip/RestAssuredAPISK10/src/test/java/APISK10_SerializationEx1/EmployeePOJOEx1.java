package APISK10_SerializationEx1;

public class EmployeePOJOEx1 {
	
	private String name;
	private int id;
	private long salary;
	private String address;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}
	public long getSalary() 
	{
		return salary;
	}
	public void setSalary(long salary) 
	{
		this.salary = salary;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	
	
	
	
	
	

}

