package POJOEx5;

import java.util.List;

import POJOEx3.EmployeeAddress3;

public class CreateEmployee5Pojo {
	
	private String name;
	private int age;
	private int salary;
	private List<String> banks;
	private EmployeeAddress4Pojo empAddress;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	public EmployeeAddress4Pojo getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(EmployeeAddress4Pojo empAddress) {
		this.empAddress = empAddress;
	}
	
	
	
	
	
	

}
