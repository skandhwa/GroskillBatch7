package POJOEx5;

public class EmployeeAddress4Pojo {
	
	private HouseDetailsPojo hdobj;
	private int zip;
	private String state;
	private String city;
	public HouseDetailsPojo getHdobj() {
		return hdobj;
	}
	public void setHdobj(HouseDetailsPojo hdobj) {
		this.hdobj = hdobj;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	
	
	

}
