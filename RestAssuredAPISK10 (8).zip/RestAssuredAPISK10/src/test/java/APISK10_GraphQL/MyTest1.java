package APISK10_GraphQL;

import org.json.JSONObject;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class MyTest1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://countries.trevorblades.com";
		
		String query="query {\r\n"
				+ "  countries {\r\n"
				+ "    code\r\n"
				+ "    name\r\n"
				+ "    capital\r\n"
				+ "  }\r\n"
				+ "}\r\n"
				+ "";
		
		JSONObject payload=new JSONObject();
		payload.put("query", query);
		String reqBody=payload.toString();
		
		String Response=given().log().all().body(reqBody).header("content-type","application/json")
		.when().post("graphql")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response().asString();
		
		System.out.println(Response);
		
		
		
		
	}

}
