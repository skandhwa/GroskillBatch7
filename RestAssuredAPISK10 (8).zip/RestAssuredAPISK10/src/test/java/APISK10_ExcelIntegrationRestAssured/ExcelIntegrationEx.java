package APISK10_ExcelIntegrationRestAssured;

import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelIntegrationEx {
	
	static XSSFWorkbook workbook;
	static XSSFSheet sheet;
	
	ExcelIntegrationEx(String excelPath, String sheetName) throws IOException
	{
		workbook =new XSSFWorkbook(ConstantsData.EXCEL_PATH);
		sheet=workbook.getSheet(ConstantsData.SHEET_NAME);
		
	
	
	}
	
	
	public static Object getData(int x,int y)
	{
		DataFormatter obj=new DataFormatter();
		Object val=	obj.formatCellValue(sheet.getRow(x).getCell(y));
		return val;
	}
	
	
	
	
	

//	public static void main(String[] args) throws IOException {
//		
//		XSSFWorkbook workbook=new XSSFWorkbook("D:/TestData1stJune.xlsx");
//		XSSFSheet sheet=workbook.getSheet("Sheet1");
//		DataFormatter obj=new DataFormatter();
//	Object val=	obj.formatCellValue(sheet.getRow(1).getCell(3));
//	System.out.println(val);
	
		
		
		
		

	

}
