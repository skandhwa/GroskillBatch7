package APISK10Authentications;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class APIKeyAuth {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://api.openweathermap.org";
		
		
	String Response=	given().log().all().headers("content-type","application/json")
		.queryParam("q", "kolkata")
		.queryParam("appid", "4c834f2c753226cb4953a66effe44611")
		.when().get("data/2.5/weather")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
		
		
		

	}

}
