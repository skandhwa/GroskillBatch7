package APISK10Authentications;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class Oauth2Example {
	
	String Access_token;
	
	@Test(priority=0)
	public void getAccessToken()
	{
		String client_id="ASyStlg4z4BjlmHNrXnDSLwFzY6j8NwPPE16opmTNUxHYf1IXRThQgb3ZN9uWeq3byeJPHlGXp_Gk2f7";
		String client_secret_id="ECKYHfIutJTW9x6PgRFePjsHJPH5MAomf34tbLqp7xmeckGaZGwM083k7ZHrY1cSnW18IYZcNKOH_chu";
		
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		
	String Response=	given().log().all().headers("content-type","application/x-www-form-urlencoded").param("grant_type","client_credentials")
		.auth().preemptive().
		
		basic(client_id, client_secret_id)
		
		.when().post("/v1/oauth2/token").then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
	
	
	JsonPath js=new JsonPath(Response);
	
 Access_token=	js.get("access_token");

System.out.println(Access_token);
System.out.println();
System.out.println();
System.out.println();
System.out.println();


	}
	
	
	
	
	
	@Test(priority=1)
	public void getActual()
	{
		RestAssured.baseURI="https://api-m.sandbox.paypal.com";
		
	String Response=	given().log().all().queryParam("page", 3)
		.queryParam("page_size",4)
		.queryParam("total_count_required", true)
		.auth().oauth2(Access_token)
		.when().get("v1/invoicing/invoices")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
		
		
	}
	
	

}
