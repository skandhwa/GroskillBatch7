package APISK10Serialization3;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException, HttpTimeoutException {
		
		EmployeePOJO3 emp1=new EmployeePOJO3();
		emp1.setName("Harry");
		emp1.setAge(35);
		emp1.setMarried(false);
		emp1.setSalary(80000);
		
		EmployeePOJO3 emp2=new EmployeePOJO3();
		emp2.setName("Tim");
		emp2.setAge(45);
		emp2.setMarried(true);
		emp2.setSalary(90000);
		
		EmployeePOJO3 emp3=new EmployeePOJO3();
		emp3.setName("Sam");
		emp3.setAge(65);
		emp3.setMarried(true);
		emp3.setSalary(100000);
		
		List<EmployeePOJO3> li=new ArrayList<EmployeePOJO3>();
		li.add(emp1);
		li.add(emp2);
		li.add(emp3);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
	
RestAssured.baseURI="https://reqres.in";
	
	Response res=	given().log().all()
		.headers("content-type","application/json").
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON)
		
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response();
	
	long time=res.getTime();
	
	if(time>5000)
	{
		throw new HttpTimeoutException("Time limit exceeded");
	}
	
	else{
		
		System.out.println("Test case passed");
		
	}
	
	
	
	System.out.println(res.asString());
		
		
		

	}

}
