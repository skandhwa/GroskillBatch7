package MyPractice1;

import static io.restassured.RestAssured.given;

import java.util.concurrent.TimeUnit;

import org.hamcrest.Matcher;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class MyTest2 {

	public static void main(String[] args) throws Exception {
		
		
		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				when().get("api/users/2").
			    then().log().all().assertThat().statusCode(200)
			    .extract().response();
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		 

	}



}
