package MyPractice1;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class HandlingStaticPayload {

	public static void main(String[] args) throws IOException {
		
		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
					headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
					queryParam("page",2).
					headers("content-type","application/json").
					
		body(new String (Files.readAllBytes(Paths.get("E:/TestData10thJan.txt")))).
					
				
					
					when().post("api/users").
				    then().log().all().assertThat().statusCode(201)
				    .extract().response();
		 
		 String Response=res.asString();
		 
		 System.out.println(Response);
			 
		

	}

}
