package MyPractice1;

import static io.restassured.RestAssured.given;

import PayloadData.CookiesCreation;
import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CookiesImplementation {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		 String res=		given().log().all().
				 cookies(CookiesCreation.cookiesDetails()).
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				
				body(Payload.addEmployeeDetails("harry","QA manager")).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response().asString();
		 
		 System.out.println(res);
		 
		
		 

	}

	}


