package MyPractice1;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import PayloadData.Payload;
import io.restassured.response.Response;

public class MapToPassTestData {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name","harry");
		mp.put("job","QA Manager");
		
		
		String Response=		given().log().all().relaxedHTTPSValidation().
				headers("x-api-key","reqres_7469d671144a471795894572391d9705").
				headers("content-type","application/json").
				body(mp).
				
				
				
				when().post("api/users").
			    then().log().all()
			    .extract().response().asString();
		
		System.out.println(Response);
		
		
		

	}

}
