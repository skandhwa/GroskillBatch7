package APISK10;

import static io.restassured.RestAssured.given;

import java.io.File;

import io.restassured.RestAssured;

public class SendingFileAsInput {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://httpbin.org";
//		File f1= new File  ("‪E:\\MyTest20.txt");
//		File f2=new File("E:\\MyTest21.txt");
//		
//		String f1="‪E:\\MyTest20.txt";
//		String f2="E:\\MyTest21.txt";
		
		File f1=new File("E://TestData17thJan.txt");
		File f2=new File("E://TestData17thJan.txt");
		
		
		String f="D:\\RandomDataGeneration.txt";
		
	String Response=	given().log().all().headers("content-type","multipart/form-data")
		.multiPart("File",f1)
		.multiPart("File",f2)
		.when().post("post")
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
		
		///   E:/MyTest20.txt
	
	//‪‪E:/MyTest21.txt
		

	}

}
