package APISK10;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class UsingHamcrestMatcherEx1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		
	String Response=	given().log().all().when().get("posts/1")
		.then().log().all()
		.body("userId", notNullValue())
		.body("id",equalTo(1))
		.body("title", startsWith("sunt"))
		.body("title", endsWith("rit"))
		.body("body", containsString("quia"))
		.body("userId", lessThan(10))
		.body("userId", greaterThan(0))
		.extract().response().asString();
	
	
	System.out.println(Response);
		
		
		
		
		
		
		

	}

}
