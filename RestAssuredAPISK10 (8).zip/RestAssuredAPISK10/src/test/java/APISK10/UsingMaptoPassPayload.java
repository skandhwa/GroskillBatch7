package APISK10;

import java.util.LinkedHashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class UsingMaptoPassPayload {

	public static void main(String[] args) {
		
		Map<String,Object>mp=new LinkedHashMap<String,Object>();
		mp.put("name","harry");
		mp.put("jobRole","Qa lead");
		mp.put("salary", 80000f);
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all().headers("content-type","application/json")
		.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(mp)
		.when().post("api/users")
		.then().assertThat().statusCode(201)
		.extract().response().asString();
	
	System.out.println(Response);
		
		

	}

}
