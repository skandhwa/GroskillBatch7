package POJOEx3;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress3 empAddress=new EmployeeAddress3();
		empAddress.setCity("Pune");
		empAddress.setPincode(908765);
		empAddress.setState("Maharastra");
		
		List<String> banks=new ArrayList<String>();
		banks.add("HDFC");
		banks.add("ICICI");
		banks.add("SBI");
		
		EmployeePOJO3 emp=new EmployeePOJO3();
		emp.setName("Harry");
		emp.setJob("QA Manager");
		emp.setSalary(78000);
		emp.setEmpAddress(empAddress);
		emp.setBanks(banks);
		emp.setMarried(false);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
	RestAssured.baseURI="https://reqres.in";
	
	 String res=		given().log().all().
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
			headers("content-type","application/json").
			body(empJSON).when().post("api/users").
		    then().log().all().assertThat().statusCode(201)
		    .extract().response().asString();
	 
	 System.out.println(res);
	 
		
		
		
		
		
		
		

	}

}
