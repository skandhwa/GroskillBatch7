package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands4 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	String tagName=	driver.findElement(By.xpath("//input[@type='email']")).getTagName();
		
		System.out.println("TagName is  "+tagName);
		
		
		
		
		
		
		
		

	}

}
