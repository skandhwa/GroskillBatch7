package MyPractice1;

public class WebElementCommands10 {

	public static void main(String[] args) {
		
		
		

	}

}
