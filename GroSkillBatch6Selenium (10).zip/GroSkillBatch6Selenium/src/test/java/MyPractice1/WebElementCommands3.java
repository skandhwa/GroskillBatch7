package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands3 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
	      driver.get("https://demo.automationtesting.in/Register.html");
	      driver.manage().window().maximize();
	      
	  String Name=    driver.findElement(By.xpath("//*[text()='Full Name* ']")).getText();
	    
	  System.out.println("Text value is  "+Name);
	  
	  
	String val=  driver.findElement(By.xpath("//input[@type='tel']")).getAttribute("pattern");
	  
		System.out.println("Attribute value of phone is  "+val);

	}

}
