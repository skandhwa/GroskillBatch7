package MyPractice1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class GetDataFromDD {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");

		Select select = new Select(driver.findElement(By.id("Skills")));

		boolean found = false;

		for (WebElement option : select.getOptions()) {
		    System.out.println(option.getText());

		    if ("Android".equalsIgnoreCase(option.getText())) {
		        found = true;
		        break;
		    }
		}

		System.out.println(found ? "Element found" : "Not Found");
		
		
		

	}

}
