package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands9 {

	public static void main(String[] args) {
		
		 WebDriver driver=new ChromeDriver();
	      driver.get("https://demo.automationtesting.in/Register.html");
	      driver.manage().window().maximize();
	      
	  WebElement ele= driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		
	    Dimension d=ele.getSize();
	    System.out.println("Size of element is  "+d.height+"  "+d.width+"  ");
	    
       
	    
	    Rectangle r=ele.getRect();
	    
	    System.out.println("Location and Size is  "+r.height+"  "+r.x+"  "+r.y);
	  
	  
	  
	}

}
