package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[text()='Images']")).click();
	String CurrentURL=	driver.getCurrentUrl();
	System.out.println("Current URL is  "+CurrentURL);
	
	String title=	driver.getTitle();
		System.out.println("Title of webpage is  "+title);
		
		
		
		

	}

}
