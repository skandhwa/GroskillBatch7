package AdvanceSeleniumConcepts;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		
		//// Handling Simple Alert
//		driver.findElement(By.xpath("//a[@href='#OKTab']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(3000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(1000);
//		
//		driver.navigate().refresh();
		
		////// Handling Confirmation Alert
		//Thread.sleep(3000);
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		//driver.switchTo().alert().accept();
//		Thread.sleep(3000);
//		driver.switchTo().alert().dismiss();
//	String text=	driver.findElement(By.xpath("//*[text()='You pressed Ok']")).getText();
//	System.out.println("Text value is  "+text);	
	
	
	
	////// Handling Prompt Alert
		
	driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
	driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
	Alert alert=driver.switchTo().alert();
	alert.sendKeys("Saurabh K");
	alert.accept();
	
	
	
	
	

	}
	
}
