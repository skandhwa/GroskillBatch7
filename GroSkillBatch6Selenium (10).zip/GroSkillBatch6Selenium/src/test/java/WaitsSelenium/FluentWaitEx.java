package WaitsSelenium;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;

public class FluentWaitEx {

	public static void main(String[] args) {
		
		 WebDriver driver=new ChromeDriver();
	       driver.get("https://demo.automationtesting.in/Register.html");
	       
	       
		FluentWait y=new FluentWait(driver);
		y.withTimeout(Duration.ofSeconds(10));
		y.pollingEvery(Duration.ofSeconds(2));
		y.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("css1")));
		y.until(ExpectedConditions.elementToBeClickable(By.xpath("xpath1")));
		y.ignoring(NoSuchElementException.class);
		

	}

}
