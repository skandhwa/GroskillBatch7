package UsingJavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetPageTitle {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver =new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("document.body.style.zoom='30%'","");
		Thread.sleep(3000);
		
		js.executeScript("history.go(0)", "");
		
		js.executeScript("window.scrollBy(200,0)","");
		
		String title=(String)js.executeScript("return document.title", "");
		System.out.println(title);

	}

}
