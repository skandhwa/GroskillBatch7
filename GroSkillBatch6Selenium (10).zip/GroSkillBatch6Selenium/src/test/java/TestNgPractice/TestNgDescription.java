package TestNgPractice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgDescription {
	
	@Test(description="verify test")
	public void test1()
	{
		System.out.println("Hello");
		Reporter.log("Hii This is test 1");
	}
	

}
