package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class TestNgAssertionsEx1 {
	
	@Test
	public void test1()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		System.out.println("Title of page is  "+title);
		
		Assert.assertEquals(title, "Google");
		Assert.assertNotEquals(title,"Google" );
		
		System.out.println("Hello");
		
		
		
		
		
	}
	
	
	

}
