package TestNgPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNgParameters2 {
	
	
	@Test
	@Parameters({"a","b","c"})
	
	public void multiply(int x,int y,int z)
	{
		int r=x*y*z;
		System.out.println(r);
	}
	

}
