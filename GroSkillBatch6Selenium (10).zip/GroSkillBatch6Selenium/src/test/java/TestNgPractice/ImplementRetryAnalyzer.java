package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;



public class ImplementRetryAnalyzer {
	
	@Test(retryAnalyzer=TestNgPractice.UsingRetryAnalyzer.class)
	
	public void display()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String title=driver.getTitle();
		Assert.assertEquals("Google123", title);
	}

}
