package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgEnabled {
	
	@Test
	public void test1()
	{
		System.out.println("Hello");
	}
	
	
	@Test(enabled=false)
	public void test2()
	{
		System.out.println("Hi");
	}
	
	
	@Test
	public void test3()
	{
		System.out.println("You are welcome");
	}
	
	

}
