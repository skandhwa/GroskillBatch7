package TestNgPractice;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class BrowserRetryAnalyzer implements IRetryAnalyzer {

    private int retryCount = 0;

    private static final String[] BROWSERS = {
            "chrome",
            "firefox",
            "edge"
    };

    @Override
    public boolean retry(ITestResult result) {

        retryCount++;

        if (retryCount < BROWSERS.length) {

            result.getTestContext()
                    .setAttribute("browser", BROWSERS[retryCount]);

            System.out.println(
                    "Retrying on browser: "
                    + BROWSERS[retryCount]);

            return true;
        }

        return false;
    }
}