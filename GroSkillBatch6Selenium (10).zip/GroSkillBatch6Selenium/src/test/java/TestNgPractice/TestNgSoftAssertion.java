package TestNgPractice;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class TestNgSoftAssertion {
	
	@Test
	public void test()
	{
		SoftAssert obj=new SoftAssert();
		System.out.println("Hello");
		
		obj.assertEquals(10,20);
		
		System.out.println("Welcome to Java");
		obj.assertEquals(30,20);
		
		System.out.println("Welcome to Selenium");
		
		obj.assertAll();
	}
	

}
