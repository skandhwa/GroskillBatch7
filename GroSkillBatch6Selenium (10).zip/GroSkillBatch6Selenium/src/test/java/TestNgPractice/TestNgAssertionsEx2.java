package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.Test;



public class TestNgAssertionsEx2 {
	
	@Test
	public void test1()
	{
//		boolean flag=true;
//		Assert.assertFalse(flag);
//		System.out.println("Hello");
		
		String str=null;
		
		Assert.assertNotNull(str);
		System.out.println("Hello");
		
		
		
		
		
		
	}
	
	
	
	

}
