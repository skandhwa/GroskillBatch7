package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgDependsOn {
	
	@Test(priority=3)
	public void logintest()
	{
		System.out.println("I am login test method");
		
	}
	
	@Test(dependsOnMethods= {"logintest"},priority=2)
	public void SearchProducttest()
	{
		System.out.println("I am Search Product test method");
		int x=9/0;
		System.out.println(x);
	}
	
	@Test(dependsOnMethods= {"SearchProducttest"},priority=1)
	public void AddToCarttest()
	{
		System.out.println("I am Add to cart test method");
	}
	
	
	@Test(dependsOnMethods= {"AddToCarttest"},priority=0)
	public void PaymentGatewaytest()
	{
		System.out.println("I am Payment Gateway test method");
	}

}
