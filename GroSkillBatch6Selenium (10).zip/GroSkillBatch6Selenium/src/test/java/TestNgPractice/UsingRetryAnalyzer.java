package TestNgPractice;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class UsingRetryAnalyzer implements IRetryAnalyzer {

	int retryLimit=3;
	int count=0;
	
	
	public boolean retry(ITestResult result) 
	{
		if(count<retryLimit)
		{
			count ++;
			return true;
		}
		
		
		return false;
	}

}
