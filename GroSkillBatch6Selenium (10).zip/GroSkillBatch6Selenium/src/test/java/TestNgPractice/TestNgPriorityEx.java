package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgPriorityEx {

	@Test(priority=5)
	public void test1()
	{
		System.out.println("I am priority 5");//4
	}
	
	
	@Test(priority=-2)
	public void test2()
	{
		System.out.println("I am priority -2");////1
	}
	
	
	@Test(priority='C')
	public void test3()
	{
		System.out.println("I am priority C");
	}
	
	
	@Test(priority=0)
	public void test4()
	{
		System.out.println("I am priority 0");///2
	}
	
	@Test
	public void test5()
	{
		System.out.println("I am default priority");///3
	}
	
	
	@Test(priority =8)
	public void Atest6()
	{
		System.out.println("I am A test priority 8");
	}
	
	@Test(priority =8)
	public void Btest6()
	{
		System.out.println("I am B test priority 8");
	}
	

}
